/**
 * Firebase Realtime Database & Firebase Auth Integration Service
 * M3CAR - Antar Jemput Ujung Kulon Jakarta
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getDatabase,
  ref,
  set,
  get,
  onValue,
  update,
  Database,
  Unsubscribe,
} from 'firebase/database';
import { getAuth, Auth } from 'firebase/auth';
import { FirebaseConfig, Order, DriverProfile, WalletTransaction, AdminSettings } from '../types';

const STORAGE_KEY_FIREBASE_CONFIG = 'm3car_firebase_config_v2';

let appInstance: FirebaseApp | null = null;
let dbInstance: Database | null = null;
let authInstance: Auth | null = null;

let unsubs: Unsubscribe[] = [];

/**
 * Load saved Firebase Config from localStorage
 */
export function getSavedFirebaseConfig(): FirebaseConfig | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_FIREBASE_CONFIG);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Save Firebase Config to localStorage
 */
export function saveFirebaseConfig(config: FirebaseConfig | null) {
  try {
    if (config) {
      localStorage.setItem(STORAGE_KEY_FIREBASE_CONFIG, JSON.stringify(config));
    } else {
      localStorage.removeItem(STORAGE_KEY_FIREBASE_CONFIG);
    }
  } catch (e) {
    console.error('Failed to save Firebase config', e);
  }
}

/**
 * Initialize Firebase App & Database
 */
export function initializeFirebase(config: FirebaseConfig): { success: boolean; error?: string } {
  try {
    if (!config.apiKey || !config.databaseURL || !config.projectId) {
      return { success: false, error: 'apiKey, databaseURL, dan projectId wajib diisi.' };
    }

    const apps = getApps();
    if (apps.length > 0) {
      appInstance = apps[0];
    } else {
      appInstance = initializeApp(config);
    }

    dbInstance = getDatabase(appInstance);
    authInstance = getAuth(appInstance);

    return { success: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return { success: false, error: message };
  }
}

/**
 * Test Firebase Connection by pinging database
 */
export async function testFirebaseConnection(config: FirebaseConfig): Promise<{ success: boolean; error?: string }> {
  try {
    const initRes = initializeFirebase(config);
    if (!initRes.success || !dbInstance) {
      return { success: false, error: initRes.error || 'Inisialisasi Firebase gagal.' };
    }

    const testRef = ref(dbInstance, '_connection_test');
    await set(testRef, {
      ping: Date.now(),
      app: 'M3CAR - Antar Jemput Ujung Kulon Jakarta',
      timestamp: new Date().toISOString(),
    });

    // Read back to confirm read permissions
    const snap = await get(testRef);
    if (!snap.exists()) {
      return { success: false, error: 'Koneksi berhasil tetapi data uji tidak terbaca (cek Rules Database).' };
    }

    // Save on success
    saveFirebaseConfig(config);
    return { success: true };
  } catch (err) {
    console.error('Firebase test error:', err);
    let errorMessage = err instanceof Error ? err.message : String(err);
    if (errorMessage.includes('PERMISSION_DENIED') || errorMessage.includes('permission_denied')) {
      errorMessage = 'Akses ditolak (permission_denied). Pastikan Realtime Database Rules mengizinkan read/write (auth != null atau test mode: true).';
    } else if (errorMessage.includes('Client is offline') || errorMessage.includes('network')) {
      errorMessage = 'Koneksi jaringan gagal. Periksa URL databaseURL Anda.';
    }
    return { success: false, error: errorMessage };
  }
}

/**
 * Real-Time Listeners for M3Car data
 */
export function setupRealtimeListeners(callbacks: {
  onOrdersChange: (orders: Order[]) => void;
  onDriversChange: (drivers: DriverProfile[]) => void;
  onSettingsChange: (settings: Partial<AdminSettings>) => void;
  onTransactionsChange: (tx: WalletTransaction[]) => void;
  onConnectionStatusChange: (connected: boolean) => void;
}) {
  // Clear any previous listeners
  unsubs.forEach((unsub) => unsub());
  unsubs = [];

  const config = getSavedFirebaseConfig();
  if (!config) {
    callbacks.onConnectionStatusChange(false);
    return;
  }

  const initRes = initializeFirebase(config);
  if (!initRes.success || !dbInstance) {
    callbacks.onConnectionStatusChange(false);
    return;
  }

  // Monitor connection state
  const connectedRef = ref(dbInstance, '.info/connected');
  const unsubConn = onValue(connectedRef, (snap) => {
    callbacks.onConnectionStatusChange(snap.val() === true);
  });
  unsubs.push(unsubConn);

  // 1. Listen to orders
  const ordersRef = ref(dbInstance, 'orders');
  const unsubOrders = onValue(ordersRef, (snap) => {
    if (snap.exists()) {
      const data = snap.val();
      const list: Order[] = Object.keys(data).map((k) => ({
        ...data[k],
        id: k,
      }));
      // Sort newest first
      list.sort((a, b) => (b.createdAt > a.createdAt ? 1 : -1));
      callbacks.onOrdersChange(list);
    }
  });
  unsubs.push(unsubOrders);

  // 2. Listen to drivers
  const driversRef = ref(dbInstance, 'drivers');
  const unsubDrivers = onValue(driversRef, (snap) => {
    if (snap.exists()) {
      const data = snap.val();
      const list: DriverProfile[] = Object.keys(data).map((k) => ({
        ...data[k],
        id: k,
        role: 'driver',
      }));
      callbacks.onDriversChange(list);
    }
  });
  unsubs.push(unsubDrivers);

  // 3. Listen to setting_admin
  const settingsRef = ref(dbInstance, 'setting_admin');
  const unsubSettings = onValue(settingsRef, (snap) => {
    if (snap.exists()) {
      const val = snap.val();
      callbacks.onSettingsChange({
        adminPhone: val.wa_admin || val.adminPhone,
        adminPasswordHash: val.kode_admin || val.adminPasswordHash,
        rates: {
          jakarta: val.harga_jakarta || 250000,
          tangerang_depok: val.harga_tangerang_depok || 275000,
          bogor_bekasi: val.harga_bogor_bekasi || 300000,
        },
        commissionRates: {
          longTrip: val.potongan_jauh ? val.potongan_jauh / 100 : 0.12,
          shortTrip: val.potongan_dekat ? val.potongan_dekat / 100 : 0.15,
        },
      });
    }
  });
  unsubs.push(unsubSettings);

  // 4. Listen to saldo_history
  const txRef = ref(dbInstance, 'saldo_history');
  const unsubTx = onValue(txRef, (snap) => {
    if (snap.exists()) {
      const data = snap.val();
      const list: WalletTransaction[] = Object.keys(data).map((k) => ({
        ...data[k],
        id: k,
      }));
      list.sort((a, b) => (b.date > a.date ? 1 : -1));
      callbacks.onTransactionsChange(list);
    }
  });
  unsubs.push(unsubTx);
}

/**
 * Push / Update single Order in Firebase
 */
export async function pushOrderToFirebase(order: Order) {
  if (!dbInstance) return;
  try {
    const orderRef = ref(dbInstance, `orders/${order.id}`);
    await set(orderRef, {
      ...order,
      titik_jemput: order.pickupLocation,
      tujuan: order.destination,
      tanggal: order.date,
      jam_jemput: order.time,
      jumlah_penumpang: order.passengers,
      harga: order.totalPrice,
      status: order.status,
      nama_driver: order.driverName || '',
      plat_nomor: order.driverPlate || '',
      no_hp_customer: order.customerPhone,
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error('Failed to sync order to Firebase:', e);
  }
}

/**
 * Update single Driver in Firebase
 */
export async function pushDriverToFirebase(driver: DriverProfile) {
  if (!dbInstance) return;
  try {
    const driverRef = ref(dbInstance, `drivers/${driver.id}`);
    await set(driverRef, {
      ...driver,
      nama: driver.name,
      no_hp: driver.phone,
      password: driver.password || 'driver123',
      foto_ktp: driver.ktpPhotoUrl,
      foto_sim: driver.simPhotoUrl,
      foto_mobil: driver.carPhotoUrl,
      plat_nomor: driver.plateNumber,
      status: driver.status, // MENUNGGU/AKTIF/DITOLAK/DIBLOKIR
      online_status: driver.isOnline ? 'ONLINE' : 'OFFLINE',
      saldo: driver.balance,
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error('Failed to sync driver to Firebase:', e);
  }
}

/**
 * Update Admin Settings in Firebase
 */
export async function pushSettingsToFirebase(settings: AdminSettings) {
  if (!dbInstance) return;
  try {
    const settingsRef = ref(dbInstance, 'setting_admin');
    await set(settingsRef, {
      harga_jakarta: settings.rates.jakarta,
      harga_tangerang_depok: settings.rates.tangerang_depok,
      harga_bogor_bekasi: settings.rates.bogor_bekasi,
      potongan_jauh: Math.round(settings.commissionRates.longTrip * 100),
      potongan_dekat: Math.round(settings.commissionRates.shortTrip * 100),
      wa_admin: settings.adminPhone,
      kode_admin: settings.adminPasswordHash,
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error('Failed to sync settings to Firebase:', e);
  }
}

/**
 * Push Saldo History Transaction to Firebase
 */
export async function pushTransactionToFirebase(tx: WalletTransaction, driverPhone?: string) {
  if (!dbInstance) return;
  try {
    const txRef = ref(dbInstance, `saldo_history/${tx.id}`);
    await set(txRef, {
      ...tx,
      no_hp_driver: driverPhone || '',
      tanggal: tx.date,
      jenis: tx.type === 'ISI_SALDO' ? 'Isi Saldo' : 'Potongan Order',
      jumlah: tx.amount,
      sisa_saldo: tx.balanceAfter,
      updatedAt: new Date().toISOString(),
    });
  } catch (e) {
    console.error('Failed to sync transaction to Firebase:', e);
  }
}

/**
 * Seed all local state to Firebase if nodes are empty
 */
export async function syncAllLocalToFirebase(data: {
  orders: Order[];
  drivers: DriverProfile[];
  settings: AdminSettings;
  transactions: WalletTransaction[];
}) {
  if (!dbInstance) return;
  try {
    // 1. Settings
    await pushSettingsToFirebase(data.settings);

    // 2. Drivers
    for (const d of data.drivers) {
      await pushDriverToFirebase(d);
    }

    // 3. Orders
    for (const o of data.orders) {
      await pushOrderToFirebase(o);
    }

    // 4. Transactions
    for (const tx of data.transactions) {
      const drv = data.drivers.find((d) => d.id === tx.driverId);
      await pushTransactionToFirebase(tx, drv?.phone);
    }
  } catch (e) {
    console.error('Initial sync to Firebase failed:', e);
  }
}
