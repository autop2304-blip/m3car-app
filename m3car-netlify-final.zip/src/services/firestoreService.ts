/**
 * Firebase Firestore Service for M3CAR - Real Cloud Database
 * Ready for 2,000,000 Passengers and Drivers
 * Project: gen-lang-client-0595665548
 */

import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getFirestore,
  Firestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  startAfter,
  QueryDocumentSnapshot,
  DocumentData,
  Unsubscribe,
  getDocFromServer,
  deleteDoc,
  updateDoc,
} from 'firebase/firestore';
import { getStorage, ref as storageRef, uploadBytes, getDownloadURL, FirebaseStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import {
  Order,
  DriverProfile,
  WalletTransaction,
  AdminSettings,
  DriverTopUpRequest,
  KeuanganAdminItem,
} from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    operationType,
    path,
  };
  console.warn('M3Car Firestore Operation Notice:', JSON.stringify(errInfo));
}

export type FirebaseConfigShape = {
  apiKey: string;
  authDomain?: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
  measurementId?: string;
  databaseURL?: string;
  firestoreDatabaseId?: string;
  [key: string]: unknown;
};

const STORAGE_KEY_FIREBASE_CONFIG_OVERRIDE = 'm3car_firebase_config_override';

export function getActiveFirebaseConfig(): FirebaseConfigShape {
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_FIREBASE_CONFIG_OVERRIDE);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.apiKey && parsed.projectId) {
          return parsed as FirebaseConfigShape;
        }
      }
    } catch {
      // ignore invalid override
    }
  }
  return firebaseConfig as FirebaseConfigShape;
}

export function setActiveFirebaseConfig(config: FirebaseConfigShape | null) {
  if (typeof window !== 'undefined') {
    if (config && config.apiKey && config.projectId) {
      localStorage.setItem(STORAGE_KEY_FIREBASE_CONFIG_OVERRIDE, JSON.stringify(config));
    } else {
      localStorage.removeItem(STORAGE_KEY_FIREBASE_CONFIG_OVERRIDE);
    }
  }
}

const resolvedFirebaseConfig = getActiveFirebaseConfig();

// Initialize Firebase App & Firestore
let app: FirebaseApp;
if (getApps().length > 0) {
  app = getApp();
} else {
  app = initializeApp(resolvedFirebaseConfig);
}

export function getActiveFirestoreDatabaseId(): string | undefined {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('m3car_firestore_database_id');
    if (saved && saved.trim()) return saved.trim();
  }
  const configDbId = resolvedFirebaseConfig.firestoreDatabaseId;
  return configDbId && String(configDbId).trim() ? String(configDbId).trim() : undefined;
}

export function setActiveFirestoreDatabaseId(databaseId: string) {
  if (typeof window !== 'undefined') {
    if (databaseId && databaseId.trim()) {
      localStorage.setItem('m3car_firestore_database_id', databaseId.trim());
    } else {
      localStorage.removeItem('m3car_firestore_database_id');
    }
  }
}

const activeDbId = getActiveFirestoreDatabaseId();
export const db: Firestore = activeDbId ? getFirestore(app, activeDbId) : getFirestore(app);
export const storage: FirebaseStorage = getStorage(app);

/**
 * Compress an image file cleanly using Canvas before Storage upload or fallback
 */
export async function compressImageFile(
  file: File,
  maxWidth = 1000,
  quality = 0.78
): Promise<{ blob: Blob; dataUrl: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context unavailable'));
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        canvas.toBlob(
          (blob) => {
            if (blob) {
              resolve({ blob, dataUrl });
            } else {
              reject(new Error('Failed to create image blob'));
            }
          },
          'image/jpeg',
          quality
        );
      };
      img.onerror = () => reject(new Error('Invalid image file'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Upload Driver KTP or SIM A to Firebase Storage:
 * - /drivers/ktp/
 * - /drivers/sim/
 * Falls back to compressed JPEG Data URL if Storage is unreachable or unprovisioned.
 */
export async function uploadDriverDocumentToStorage(
  file: File,
  docType: 'ktp' | 'sim',
  driverPhoneOrId: string
): Promise<{ url: string; storagePath: string; uploadedToStorage: boolean }> {
  const safeKey = (driverPhoneOrId || 'driver').replace(/[^a-zA-Z0-9_-]/g, '') || 'driver';
  const fileName = `${safeKey}_${Date.now()}.jpg`;
  const folderPath = docType === 'ktp' ? `/drivers/ktp/${fileName}` : `/drivers/sim/${fileName}`;
  const cleanRefPath = `drivers/${docType}/${fileName}`;

  const { blob, dataUrl } = await compressImageFile(file, 960, 0.76);

  try {
    const fileRef = storageRef(storage, cleanRefPath);
    const uploadTask = uploadBytes(fileRef, blob, {
      contentType: 'image/jpeg',
      customMetadata: {
        docType,
        driverRef: safeKey,
      },
    });
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(() => reject(new Error('Storage upload timeout')), 8000)
    );
    await Promise.race([uploadTask, timeoutPromise]);
    const downloadUrl = await getDownloadURL(fileRef);
    return {
      url: downloadUrl,
      storagePath: folderPath,
      uploadedToStorage: true,
    };
  } catch (err) {
    console.warn(`Firebase Storage upload fallback (${folderPath}):`, err);
    return {
      url: dataUrl,
      storagePath: folderPath,
      uploadedToStorage: false,
    };
  }
}

export function normalizeDriverStatusFromDb(rawStatus?: string): 'MENUNGGU' | 'AKTIF' | 'DIBLOKIR' | 'DITOLAK' {
  const s = String(rawStatus || '').toLowerCase().trim();
  if (s === 'waiting_approval' || s === 'menunggu' || s === 'pending') return 'MENUNGGU';
  if (s === 'approved' || s === 'active' || s === 'aktif') return 'AKTIF';
  if (s === 'rejected' || s === 'ditolak') return 'DITOLAK';
  if (s === 'blocked' || s === 'diblokir') return 'DIBLOKIR';
  return 'MENUNGGU';
}

export function mapDriverStatusToDb(status: string): string {
  const s = String(status || '').toUpperCase().trim();
  if (s === 'MENUNGGU' || s === 'WAITING_APPROVAL') return 'waiting_approval';
  if (s === 'AKTIF' || s === 'APPROVED') return 'approved';
  if (s === 'DITOLAK' || s === 'REJECTED') return 'rejected';
  if (s === 'DIBLOKIR' || s === 'BLOCKED') return 'blocked';
  return 'waiting_approval';
}

export function normalizeOrderStatusFromDb(rawStatus?: string): Order['status'] {
  const s = String(rawStatus || '').toUpperCase().trim();
  if (!s || s === 'PENDING' || s === 'MENUNGGU' || s === 'MENCARI_DRIVER') return 'MENCARI_DRIVER';
  if (s === 'DRIVER_DITEMUKAN' || s === 'DITERIMA' || s === 'ACCEPTED') return 'DRIVER_DITEMUKAN';
  if (s === 'DRIVER_OTW' || s === 'OTW_JEMPUT' || s === 'OTW') return 'DRIVER_OTW';
  if (s === 'DIJEMPUT' || s === 'SUDAH_JEMPUT' || s === 'DALAM_PERJALANAN' || s === 'ON_TRIP') return 'SUDAH_JEMPUT';
  if (s === 'SUDAH_SAMPAI' || s === 'SAMPAI' || s === 'ARRIVED') return 'SUDAH_SAMPAI';
  if (s === 'SELESAI' || s === 'COMPLETED' || s === 'DONE') return 'SELESAI';
  if (s === 'DIBATALKAN' || s === 'BATAL' || s === 'CANCELLED' || s === 'DITOLAK' || s === 'REJECTED') return 'DIBATALKAN';
  return 'MENCARI_DRIVER';
}

export interface CustomerData {
  id: string;
  nama: string;
  no_hp: string;
  alamat?: string;
  tanggal_daftar: string;
  role?: string;
  name?: string;
  phone?: string;
  avatarUrl?: string;
  foto_profil?: string;
  createdAt?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  sourceCollection?: string;
}

export interface DriverData {
  id: string;
  nama: string;
  no_hp: string;
  plat_mobil: string;
  foto_mobil: string;
  status_online: boolean;
  saldo: number;
  tanggal_daftar: string;
  password?: string;
  status?: string;
  carModel?: string;
  plateNumber?: string;
  isOnline?: boolean;
  balance?: number;
  ktpPhotoUrl?: string;
  simPhotoUrl?: string;
  carPhotoUrl?: string;
  avatarUrl?: string;
  rating?: number;
  totalTrips?: number;
  registeredAt?: string;
  isDeleted?: boolean;
  deletedAt?: string;
}

let activeOrdersUnsub: Unsubscribe | null = null;
let activeDriversUnsub: Unsubscribe | null = null;
let customersUnsub: Unsubscribe | null = null;
let customersLegacyUnsub: Unsubscribe | null = null;
let penumpangUnsub: Unsubscribe | null = null;
let usersCustomerUnsub: Unsubscribe | null = null;
let adminSettingsUnsub: Unsubscribe | null = null;
let topUpRequestsUnsub: Unsubscribe | null = null;
let saldoHistoryUnsub: Unsubscribe | null = null;
let keuanganAdminUnsub: Unsubscribe | null = null;

/**
 * Validate Connection to Firestore at Boot
 */
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, '_connection_test', 'ping'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firestore is running in offline-first mode.');
    } else {
      console.info('Firestore pinged successfully.');
    }
    return true;
  }
}

/**
 * Normalizes customer object for both storage and UI
 */
export function formatCustomerPayload(customer: Partial<CustomerData>): CustomerData {
  const phone = customer.no_hp || customer.phone || '';
  const name = customer.nama || customer.name || 'Penumpang M3Car';
  const id = customer.id || `cust-${phone.replace(/\D/g, '') || Date.now()}`;
  const now = new Date().toLocaleString('id-ID');
  const avatar = customer.avatarUrl || customer.foto_profil;

  return {
    id,
    nama: name,
    no_hp: phone,
    alamat: customer.alamat || 'Ujung Kulon / Jakarta',
    tanggal_daftar: customer.tanggal_daftar || customer.createdAt || now,
    name,
    phone,
    avatarUrl: avatar,
    foto_profil: avatar,
    role: 'customer',
    createdAt: customer.createdAt || now,
  };
}

/**
 * Save Customer / Penumpang to Firestore (customers collection)
 */
export async function saveCustomerToFirestore(customer: Partial<CustomerData>): Promise<CustomerData> {
  const payload = formatCustomerPayload(customer);
  try {
    const custDoc = doc(db, 'customers', payload.id);
    await setDoc(custDoc, payload, { merge: true });
    return payload;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `customers/${payload.id}`);
    return payload;
  }
}

/**
 * Get or query customer/penumpang by phone number across existing collections
 */
export async function getCustomerByPhone(phone: string): Promise<CustomerData | null> {
  const collectionsToCheck = ['customers', 'users_customer', 'penumpang'];
  for (const colName of collectionsToCheck) {
    try {
      const q = query(collection(db, colName), where('no_hp', '==', phone), limit(1));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const d = snap.docs[0];
        return { id: d.id, ...d.data(), sourceCollection: colName } as CustomerData;
      }
      const q2 = query(collection(db, colName), where('phone', '==', phone), limit(1));
      const snap2 = await getDocs(q2);
      if (!snap2.empty) {
        const d = snap2.docs[0];
        return { id: d.id, ...d.data(), sourceCollection: colName } as CustomerData;
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.GET, colName);
    }
  }
  return null;
}

/**
 * Save / Update Driver in Firestore (collection: drivers)
 * Exact required schema:
 * - collection: drivers
 * - field: name, phone, plate, car, ktpUrl, simUrl
 * - status: waiting_approval (or approved / rejected / blocked)
 */
// In-memory only secret cache (never persisted to localStorage)
const driverSecretsCache = new Map<
  string,
  {
    passwordHash?: string;
    recoveryCodeHash?: string;
    recoveryCodeExpiresAt?: string;
  }
>();

export function getCachedDriverSecrets(driverId: string) {
  return driverSecretsCache.get(driverId) || {};
}

export function setCachedDriverSecrets(
  driverId: string,
  secrets: {
    passwordHash?: string;
    recoveryCodeHash?: string;
    recoveryCodeExpiresAt?: string;
  }
) {
  const prev = driverSecretsCache.get(driverId) || {};
  driverSecretsCache.set(driverId, { ...prev, ...secrets });
}

function normalizePhoneDb(raw: string): string {
  if (!raw) return '';
  let cleaned = String(raw).replace(/\D/g, '');
  if (cleaned.startsWith('62')) {
    cleaned = '0' + cleaned.slice(2);
  } else if (cleaned.startsWith('8')) {
    cleaned = '0' + cleaned;
  }
  return cleaned;
}

export async function saveDriverToFirestore(driver: DriverProfile): Promise<void> {
  const now = new Date().toLocaleString('id-ID');
  const dbStatus = mapDriverStatusToDb(driver.status || 'MENUNGGU');
  const plateVal = driver.plateNumber || driver.plate || '';
  const carVal = driver.carModel || driver.car || '';
  const ktpVal = driver.ktpUrl || driver.ktpPhotoUrl || '';
  const simVal = driver.simUrl || driver.simPhotoUrl || '';

  const resolvedSaldo = Number(driver.saldo ?? driver.balance ?? 0);

  const payload: Record<string, unknown> = {
    id: driver.id,
    name: driver.name,
    nama: driver.name,
    phone: driver.phone,
    no_hp: driver.phone,
    plate: plateVal,
    plat_mobil: plateVal,
    car: carVal,
    ktpUrl: ktpVal,
    simUrl: simVal,
    status: dbStatus,
    // Operational & compatibility fields
    statusLabel: driver.status || 'MENUNGGU',
    plateNumber: plateVal,
    carModel: carVal,
    ktpPhotoUrl: ktpVal,
    simPhotoUrl: simVal,
    rejectionReason: driver.rejectionReason || '',
    blockReason: driver.blockReason || '',
    isOnline: Boolean(driver.isOnline),
    balance: resolvedSaldo,
    saldo: resolvedSaldo,
    rating: driver.rating || 5.0,
    totalTrips: driver.totalTrips || 0,
    registeredAt: driver.registeredAt || now,
    isDeleted: Boolean(driver.isDeleted),
    deletedAt: driver.deletedAt || '',
    updatedAt: new Date().toISOString(),
  };

  // Never store plaintext password; only persist passwordHash when explicitly supplied
  if (driver.passwordHash) {
    payload.passwordHash = driver.passwordHash;
    payload.hasPassword = true;
    payload.passwordUpdatedAt = driver.passwordUpdatedAt || new Date().toISOString();
    setCachedDriverSecrets(driver.id, { passwordHash: driver.passwordHash });
  } else if (typeof driver.hasPassword === 'boolean') {
    payload.hasPassword = driver.hasPassword;
  }

  try {
    const driverDoc = doc(db, 'drivers', driver.id);
    await setDoc(driverDoc, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `drivers/${driver.id}`);
  }
}

export async function updateDriverPasswordHashInFirestore(
  driverId: string,
  passwordHash: string,
  passwordUpdatedAt: string,
  clearRecovery = false
): Promise<void> {
  const driverRef = doc(db, 'drivers', driverId);
  const updatePayload: Record<string, unknown> = {
    passwordHash,
    hasPassword: true,
    passwordUpdatedAt,
    updatedAt: new Date().toISOString(),
  };
  if (clearRecovery) {
    updatePayload.recoveryCodeHash = '';
    updatePayload.recoveryCodeExpiresAt = '';
  }

  setCachedDriverSecrets(driverId, {
    passwordHash,
    ...(clearRecovery ? { recoveryCodeHash: '', recoveryCodeExpiresAt: '' } : {}),
  });

  try {
    await updateDoc(driverRef, updatePayload);
  } catch (error) {
    try {
      await setDoc(driverRef, { id: driverId, ...updatePayload }, { merge: true });
    } catch (fallbackError) {
      handleFirestoreError(fallbackError || error, OperationType.UPDATE, `drivers/${driverId}`);
    }
  }
}

export async function updateDriverRecoveryCodeHashInFirestore(
  driverId: string,
  recoveryCodeHash: string,
  recoveryCodeExpiresAt: string
): Promise<void> {
  const driverRef = doc(db, 'drivers', driverId);
  const updatePayload: Record<string, unknown> = {
    recoveryCodeHash,
    recoveryCodeExpiresAt,
    updatedAt: new Date().toISOString(),
  };

  setCachedDriverSecrets(driverId, { recoveryCodeHash, recoveryCodeExpiresAt });

  try {
    await updateDoc(driverRef, updatePayload);
  } catch (error) {
    try {
      await setDoc(driverRef, { id: driverId, ...updatePayload }, { merge: true });
    } catch (fallbackError) {
      handleFirestoreError(fallbackError || error, OperationType.UPDATE, `drivers/${driverId}`);
    }
  }
}

export async function fetchDriverByPhoneFromFirestore(phone: string): Promise<{
  driver: DriverProfile;
  passwordHash?: string;
  recoveryCodeHash?: string;
  recoveryCodeExpiresAt?: string;
} | null> {
  const target = normalizePhoneDb(phone);
  if (!target) return null;
  try {
    const snap = await Promise.race([
      getDocs(collection(db, 'drivers')),
      new Promise<never>((_, reject) => setTimeout(() => reject(new Error('Firestore lookup timeout')), 5000)),
    ]);
    for (const d of snap.docs) {
      const data = d.data();
      const docPhone = normalizePhoneDb(String(data.phone || data.no_hp || data.hp || ''));
      if (docPhone && docPhone === target) {
        const normalizedStatus = normalizeDriverStatusFromDb(data.status || data.statusLabel);
        const ktpUrl = data.ktpUrl || data.ktpPhotoUrl || data.foto_ktp || '';
        const simUrl = data.simUrl || data.simPhotoUrl || data.foto_sim || '';
        const plateVal = data.plate || data.plateNumber || data.plat_mobil || data.plat_nomor || '';
        const carVal = data.car || data.carModel || data.mobil || 'Toyota Avanza';
        const rawSaldo = data.saldo !== undefined && data.saldo !== null ? Number(data.saldo) : undefined;
        const rawBalance = data.balance !== undefined && data.balance !== null ? Number(data.balance) : undefined;
        const resolvedBalance =
          rawSaldo !== undefined && (rawBalance === undefined || rawBalance === 0)
            ? rawSaldo
            : rawBalance ?? rawSaldo ?? 0;

        const passwordHash = typeof data.passwordHash === 'string' ? data.passwordHash : undefined;
        const recoveryCodeHash =
          typeof data.recoveryCodeHash === 'string' ? data.recoveryCodeHash : undefined;
        const recoveryCodeExpiresAt =
          typeof data.recoveryCodeExpiresAt === 'string' ? data.recoveryCodeExpiresAt : undefined;

        setCachedDriverSecrets(d.id, { passwordHash, recoveryCodeHash, recoveryCodeExpiresAt });

        const {
          password: _omitPw,
          passwordHash: _omitHash,
          recoveryCodeHash: _omitRecHash,
          recoveryCodeExpiresAt: _omitRecExp,
          ...cleanData
        } = data;

        const driver: DriverProfile = {
          id: d.id,
          ...cleanData,
          name: data.name || data.nama || 'Driver M3Car',
          phone: data.phone || data.no_hp || data.hp || '',
          plateNumber: plateVal,
          plate: plateVal,
          carModel: carVal,
          car: carVal,
          ktpPhotoUrl: ktpUrl,
          ktpUrl,
          simPhotoUrl: simUrl,
          simUrl,
          isOnline: data.isOnline !== undefined ? Boolean(data.isOnline) : data.status_online === true,
          balance: resolvedBalance,
          saldo: resolvedBalance,
          status: normalizedStatus,
          rawStatus: data.status || 'waiting_approval',
          role: 'driver',
          rating: data.rating || 5.0,
          totalTrips: data.totalTrips || 0,
          registeredAt: data.registeredAt || data.tanggal_daftar || '',
          hasPassword: Boolean(passwordHash || data.hasPassword),
          passwordUpdatedAt: data.passwordUpdatedAt || undefined,
        } as DriverProfile;

        return { driver, passwordHash, recoveryCodeHash, recoveryCodeExpiresAt };
      }
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'drivers');
  }
  return null;
}

/**
 * Update Driver approval/rejection status directly using updateDoc(driverRef, { status })
 */
export async function updateDriverStatusInFirestore(
  driverId: string,
  dbStatus: 'waiting_approval' | 'approved' | 'rejected' | 'blocked',
  extra?: {
    rejectionReason?: string;
    blockReason?: string;
    isOnline?: boolean;
  }
): Promise<void> {
  const driverRef = doc(db, 'drivers', driverId);
  const statusLabel =
    dbStatus === 'approved'
      ? 'AKTIF'
      : dbStatus === 'rejected'
      ? 'DITOLAK'
      : dbStatus === 'blocked'
      ? 'DIBLOKIR'
      : 'MENUNGGU';

  const updatePayload: Record<string, unknown> = {
    status: dbStatus,
    statusLabel,
    updatedAt: new Date().toISOString(),
  };

  if (typeof extra?.isOnline === 'boolean') {
    updatePayload.isOnline = extra.isOnline;
  }
  if (extra?.rejectionReason !== undefined) {
    updatePayload.rejectionReason = extra.rejectionReason;
  }
  if (extra?.blockReason !== undefined) {
    updatePayload.blockReason = extra.blockReason;
  }

  try {
    await updateDoc(driverRef, updatePayload);
  } catch (error) {
    // Fallback to merge setDoc if document didn't exist in Firestore yet
    try {
      await setDoc(driverRef, { id: driverId, ...updatePayload }, { merge: true });
    } catch (fallbackError) {
      handleFirestoreError(fallbackError || error, OperationType.UPDATE, `drivers/${driverId}`);
    }
  }
}

/**
 * Save / Update Order in Firestore (orders collection)
 */
export async function saveOrderToFirestore(order: Order): Promise<void> {
  const now = new Date().toLocaleString('id-ID');
  const dariVal = order.dari || order.pickupLocation || '';
  const keVal = order.ke || order.destination || '';
  const hargaVal = Number(order.harga ?? order.totalPrice ?? 270000);
  const statusLower =
    order.status === 'MENCARI_DRIVER'
      ? 'mencari_driver'
      : order.status === 'DRIVER_OTW'
      ? 'otw_jemput'
      : order.status === 'DRIVER_DITEMUKAN' || order.status === 'SUDAH_JEMPUT'
      ? 'dalam_perjalanan'
      : order.status === 'SELESAI'
      ? 'selesai'
      : 'dibatalkan';

  const payload = {
    ...order,
    id: order.id,
    id_order: order.orderNumber || order.id,
    customerId: order.customerId || `cust-${(order.customerPhone || '').replace(/\D/g, '')}`,
    id_customer: order.customerPhone,
    id_driver: order.driverId || '',
    dari: dariVal,
    ke: keVal,
    titik_jemput: dariVal,
    tujuan: keVal,
    jarak_km: order.deviationKm ? 83.6 + order.deviationKm : 83.6,
    harga: hargaVal,
    status: order.status,
    status_db: statusLower,
    tanggal_order: order.date || now,
    customerName: order.customerName,
    customerPhone: order.customerPhone,
    pickupLocation: dariVal,
    destination: keVal,
    driverId: order.driverId || '',
    driverName: order.driverName || '',
    driverPhone: order.driverPhone || '',
    driverPlate: order.driverPlate || '',
    driverCar: order.driverCar || '',
    passengers: order.passengers || 1,
    totalPrice: hargaVal,
    commissionAmount: order.commissionAmount || 0,
    driverEarnings: order.driverEarnings || 0,
    tollRoute: order.tollRoute || 'Tol Jakarta-Merak + Tol Serang-Panimbang 83,6 km',
    eta: order.eta || '6 jam 30 menit',
    paymentMethod: order.paymentMethod || 'TUNAI',
    paymentStatus: order.paymentStatus || 'BELUM_BAYAR',
    createdAt: order.createdAt || now,
    updatedAt: new Date().toISOString(),
  };

  try {
    const orderDoc = doc(db, 'orders', order.id);
    await setDoc(orderDoc, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `orders/${order.id}`);
  }
}

export async function updateOrderInFirestore(orderId: string, fields: Record<string, unknown>): Promise<void> {
  const orderRef = doc(db, 'orders', orderId);
  const payload = {
    ...fields,
    updatedAt: new Date().toISOString(),
  };
  try {
    await updateDoc(orderRef, payload);
  } catch (error) {
    try {
      await setDoc(orderRef, { id: orderId, ...payload }, { merge: true });
    } catch (fallbackError) {
      handleFirestoreError(fallbackError || error, OperationType.UPDATE, `orders/${orderId}`);
    }
  }
}

/**
 * Save Transaction in Firestore (saldo_history collection)
 */
export async function saveTransactionToFirestore(tx: WalletTransaction, driverPhone?: string): Promise<void> {
  const payload = {
    ...tx,
    id: tx.id,
    driverId: tx.driverId,
    driverPhone: driverPhone || '',
    date: tx.date,
    type: tx.type,
    amount: tx.amount,
    balanceAfter: tx.balanceAfter,
    description: tx.description,
    orderId: tx.orderId || '',
    paymentMethod: tx.paymentMethod,
    status: tx.status,
    updatedAt: new Date().toISOString(),
  };

  try {
    const txDoc = doc(db, 'saldo_history', tx.id);
    await setDoc(txDoc, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `saldo_history/${tx.id}`);
  }
}

/**
 * Save Admin Operational Settings in Firestore (setting_admin/config)
 */
export async function saveAdminSettingsToFirestore(settings: AdminSettings): Promise<void> {
  try {
    const { adminPasswordHash: _omittedSecret, ...safeSettings } = settings;
    const settingDoc = doc(db, 'setting_admin', 'config');
    await setDoc(
      settingDoc,
      {
        ...safeSettings,
        adminPhone: settings.adminPhone || '085811594114',
        companyBank: settings.companyBank,
        rates: settings.rates,
        commissionRates: settings.commissionRates,
        routes: settings.routes || [],
        tariffs: settings.tariffs || [],
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'setting_admin/config');
  }
}

/**
 * Save Top Up Request to Firestore
 */
export async function saveTopUpRequestToFirestore(req: DriverTopUpRequest): Promise<void> {
  try {
    const reqDoc = doc(db, 'topup_requests', req.id);
    await setDoc(
      reqDoc,
      {
        ...req,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `topup_requests/${req.id}`);
  }
}

/**
 * Save / Update Keuangan Admin item (keuangan_admin collection)
 */
export async function saveKeuanganAdminToFirestore(item: KeuanganAdminItem): Promise<void> {
  try {
    const docRef = doc(db, 'keuangan_admin', item.id);
    await setDoc(
      docRef,
      {
        ...item,
        id_transaksi: item.id_transaksi || item.id,
        isDeleted: Boolean(item.isDeleted),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `keuangan_admin/${item.id}`);
  }
}

/**
 * Permanently Delete records from Firestore (Kotak Sampah: Hapus Permanen)
 */
export async function deleteOrderFromFirestore(orderId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'orders', orderId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `orders/${orderId}`);
  }
}

export async function deleteDriverFromFirestore(driverId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'drivers', driverId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `drivers/${driverId}`);
  }
}

export async function deleteCustomerFromFirestore(customerId: string): Promise<void> {
  const cols = ['customers', 'users_customer', 'penumpang', 'users'];
  for (const colName of cols) {
    try {
      await deleteDoc(doc(db, colName, customerId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${colName}/${customerId}`);
    }
  }
}

export async function deleteKeuanganAdminFromFirestore(keuanganId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'keuangan_admin', keuanganId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `keuangan_admin/${keuanganId}`);
  }
}

export async function deleteTransactionFromFirestore(txId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'saldo_history', txId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `saldo_history/${txId}`);
  }
}

export async function deleteTopUpRequestFromFirestore(requestId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'topup_requests', requestId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `topup_requests/${requestId}`);
  }
}

export async function clearAllTransactionsFromFirestore(txIds: string[]): Promise<void> {
  for (const id of txIds) {
    try {
      await deleteDoc(doc(db, 'saldo_history', id));
    } catch (e) {
      console.warn('Failed to delete tx:', id, e);
    }
  }
}

export async function clearAllCustomersFromFirestore(customerIds: string[]): Promise<void> {
  const cols = ['customers', 'users_customer', 'penumpang'];
  for (const id of customerIds) {
    for (const colName of cols) {
      try {
        await deleteDoc(doc(db, colName, id));
      } catch (e) {
        console.warn(`Failed to delete customer from ${colName}:`, id, e);
      }
    }
  }
}

export async function clearAllTopUpRequestsFromFirestore(requestIds: string[]): Promise<void> {
  for (const id of requestIds) {
    try {
      await deleteDoc(doc(db, 'topup_requests', id));
    } catch (e) {
      console.warn('Failed to delete topup request:', id, e);
    }
  }
}

/**
 * REALTIME LISTENER FOR ACTIVE ORDERS ONLY (OPTIMIZED FOR 2 MILLION USERS)
 * Does NOT download millions of finished trips.
 * Listens strictly to active orders: MENCARI_DRIVER, DRIVER_OTW, DRIVER_DITEMUKAN
 */
export function setupRealtimeListeners(callbacks: {
  onActiveOrdersChange: (orders: Order[]) => void;
  onDriversChange: (drivers: DriverProfile[]) => void;
  onCustomersChange?: (customers: CustomerData[]) => void;
  onSettingsChange: (settings: Partial<AdminSettings>) => void;
  onTransactionsChange: (tx: WalletTransaction[]) => void;
  onTopUpRequestsChange?: (requests: DriverTopUpRequest[]) => void;
  onKeuanganAdminChange?: (items: KeuanganAdminItem[]) => void;
  onConnected: (connected: boolean) => void;
}) {
  // Clear any existing listeners
  if (activeOrdersUnsub) activeOrdersUnsub();
  if (activeDriversUnsub) activeDriversUnsub();
  if (customersUnsub) customersUnsub();
  if (customersLegacyUnsub) customersLegacyUnsub();
  if (penumpangUnsub) penumpangUnsub();
  if (usersCustomerUnsub) usersCustomerUnsub();
  if (adminSettingsUnsub) adminSettingsUnsub();
  if (topUpRequestsUnsub) topUpRequestsUnsub();
  if (saldoHistoryUnsub) saldoHistoryUnsub();
  if (keuanganAdminUnsub) keuanganAdminUnsub();

  try {
    callbacks.onConnected(true);

    const DUMMY_DRIVER_IDS = new Set(['DRV-001', 'drv-2', 'drv-3']);
    const DUMMY_DRIVER_NAMES = new Set(['asep saepudin', 'dedi mulyadi', 'hendra wijaya', 'ira wijaya', 'rudi hartono', 'jamaludin']);
    const DUMMY_ORDER_IDS = new Set(['ord-malaysia-931', 'ord-101']);
    const DUMMY_CUST_IDS = new Set(['CUST-001', 'CUST-002', 'cust-081288990011']);
    const DUMMY_TX_IDS = new Set(['tx-001', 'tx-002']);
    const DUMMY_TOPUP_IDS = new Set(['topup-req-1', 'topup-req-2']);
    const DUMMY_KEUANGAN_IDS = new Set(['tx-init-1', 'tx-init-2', 'tx-init-3']);

    // 1. ORDERS: Realtime listener langsung pada collection(db, 'orders')
    const qOrder = collection(db, 'orders');

    activeOrdersUnsub = onSnapshot(
      qOrder,
      (snapshot) => {
        const orderList: Order[] = [];
        snapshot.forEach((d) => {
          if (DUMMY_ORDER_IDS.has(d.id)) return;
          const data = d.data();
          const dariVal = data.dari || data.pickupLocation || data.titik_jemput || data.jemput || '';
          const keVal = data.ke || data.destination || data.tujuan || '';
          const hargaVal = Number(data.harga ?? data.totalPrice ?? 270000);
          const normStatus = normalizeOrderStatusFromDb(data.status || data.status_db);
          orderList.push({
            id: d.id,
            ...data,
            orderNumber: data.orderNumber || data.id_order || `M3-${d.id.slice(-6)}`,
            customerId: data.customerId || data.id_customer || '',
            customerPhone: data.customerPhone || data.no_hp || data.phone || data.no_hp_customer || data.id_customer || '',
            customerName: data.customerName || data.nama || data.nama_customer || data.nama_penumpang || 'Penumpang M3Car',
            pickupLocation: dariVal,
            dari: dariVal,
            destination: keVal,
            ke: keVal,
            totalPrice: hargaVal,
            harga: hargaVal,
            driverId: data.driverId || data.id_driver || '',
            driverName: data.driverName || data.nama_driver || '',
            driverPlate: data.driverPlate || data.plat_mobil || data.plat_nomor || '',
            status: normStatus,
            createdAt: data.createdAt || data.tanggal_order || new Date().toLocaleString('id-ID'),
          } as Order);
        });
        orderList.sort((a, b) => ((b.createdAt || '') > (a.createdAt || '') ? 1 : -1));
        callbacks.onActiveOrdersChange(orderList);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'orders');
      }
    );

    // 2. DRIVERS: Realtime listener langsung pada collection(db, 'drivers')
    const qDriver = collection(db, 'drivers');

    activeDriversUnsub = onSnapshot(
      qDriver,
      (snapshot) => {
        const driversList: DriverProfile[] = [];
        snapshot.forEach((d) => {
          const data = d.data();
          const rawName = String(data.name || data.nama || '').trim().toLowerCase();
          if (DUMMY_DRIVER_IDS.has(d.id) || DUMMY_DRIVER_NAMES.has(rawName)) {
            return;
          }
          const normalizedStatus = normalizeDriverStatusFromDb(data.status || data.statusLabel);
          const ktpUrl = data.ktpUrl || data.ktpPhotoUrl || data.foto_ktp || '';
          const simUrl = data.simUrl || data.simPhotoUrl || data.foto_sim || '';
          const plateVal = data.plate || data.plateNumber || data.plat_mobil || data.plat_nomor || '';
          const carVal = data.car || data.carModel || data.mobil || 'Toyota Avanza';

          const rawSaldo = data.saldo !== undefined && data.saldo !== null ? Number(data.saldo) : undefined;
          const rawBalance = data.balance !== undefined && data.balance !== null ? Number(data.balance) : undefined;
          const resolvedBalance =
            rawSaldo !== undefined && (rawBalance === undefined || rawBalance === 0)
              ? rawSaldo
              : rawBalance ?? rawSaldo ?? 0;

          const passwordHash =
            typeof data.passwordHash === 'string' ? data.passwordHash : undefined;
          const recoveryCodeHash =
            typeof data.recoveryCodeHash === 'string' ? data.recoveryCodeHash : undefined;
          const recoveryCodeExpiresAt =
            typeof data.recoveryCodeExpiresAt === 'string' ? data.recoveryCodeExpiresAt : undefined;

          setCachedDriverSecrets(d.id, {
            passwordHash,
            recoveryCodeHash,
            recoveryCodeExpiresAt,
          });

          const {
            password: _omitPw,
            passwordHash: _omitHash,
            recoveryCodeHash: _omitRecHash,
            recoveryCodeExpiresAt: _omitRecExp,
            ...cleanData
          } = data;

          driversList.push({
            id: d.id,
            ...cleanData,
            name: data.name || data.nama || 'Driver M3Car',
            phone: data.phone || data.no_hp || data.hp || '',
            plateNumber: plateVal,
            plate: plateVal,
            carModel: carVal,
            car: carVal,
            ktpPhotoUrl: ktpUrl,
            ktpUrl,
            simPhotoUrl: simUrl,
            simUrl,
            isOnline: data.isOnline !== undefined ? Boolean(data.isOnline) : data.status_online === true,
            balance: resolvedBalance,
            saldo: resolvedBalance,
            status: normalizedStatus,
            rawStatus: data.status || 'waiting_approval',
            role: 'driver',
            rating: data.rating || 5.0,
            totalTrips: data.totalTrips || 0,
            registeredAt: data.registeredAt || data.tanggal_daftar || '',
            hasPassword: Boolean(passwordHash || data.hasPassword),
            passwordUpdatedAt: data.passwordUpdatedAt || undefined,
          } as DriverProfile);
        });
        callbacks.onDriversChange(driversList);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'drivers');
      }
    );

    // 2b. PENUMPANG: Realtime listener langsung pada collection(db, 'customers') + merge fallback dari 'penumpang', 'users_customer', 'users'
    const customerBuckets: Record<'customers' | 'users_customer' | 'penumpang' | 'users', Map<string, CustomerData>> = {
      customers: new Map(),
      users_customer: new Map(),
      penumpang: new Map(),
      users: new Map(),
    };

    const emitMergedCustomers = () => {
      if (!callbacks.onCustomersChange) return;
      const merged = new Map<string, CustomerData>();
      // Lower priority fallbacks first, then 'customers' overrides with highest priority
      const orderKeys: Array<'users' | 'users_customer' | 'penumpang' | 'customers'> = [
        'users',
        'users_customer',
        'penumpang',
        'customers',
      ];
      for (const colKey of orderKeys) {
        customerBuckets[colKey].forEach((val, id) => {
          merged.set(id, val);
        });
      }
      callbacks.onCustomersChange(Array.from(merged.values()));
    };

    const mapCustomerSnapshot = (
      colKey: 'customers' | 'users_customer' | 'penumpang' | 'users',
      snapshot: any,
      filterUsersRole = false
    ) => {
      const nextMap = new Map<string, CustomerData>();
      snapshot.forEach((d: any) => {
        if (DUMMY_CUST_IDS.has(d.id)) return;
        const data = d.data();
        if (filterUsersRole) {
          const r = String(data.role || '').toLowerCase();
          if (r === 'admin' || r === 'driver') return;
        }
        const nama = data.nama || data.name || data.nama_lengkap || 'Penumpang M3Car';
        const noHp = data.no_hp || data.phone || data.hp || data.whatsapp || '';
        nextMap.set(d.id, {
          id: d.id,
          ...data,
          nama,
          name: nama,
          no_hp: noHp,
          phone: noHp,
          alamat: data.alamat || data.address || 'Ujung Kulon / Jakarta',
          tanggal_daftar: data.tanggal_daftar || data.createdAt || data.tanggal || '',
          role: 'customer',
          sourceCollection: colKey,
        } as CustomerData);
      });
      customerBuckets[colKey] = nextMap;
      emitMergedCustomers();
    };

    customersUnsub = onSnapshot(
      collection(db, 'customers'),
      (snap) => mapCustomerSnapshot('customers', snap),
      (err) => handleFirestoreError(err, OperationType.LIST, 'customers')
    );

    customersLegacyUnsub = onSnapshot(
      collection(db, 'users_customer'),
      (snap) => mapCustomerSnapshot('users_customer', snap),
      (err) => handleFirestoreError(err, OperationType.LIST, 'users_customer')
    );

    penumpangUnsub = onSnapshot(
      collection(db, 'penumpang'),
      (snap) => mapCustomerSnapshot('penumpang', snap),
      (err) => handleFirestoreError(err, OperationType.LIST, 'penumpang')
    );

    usersCustomerUnsub = onSnapshot(
      collection(db, 'users'),
      (snap) => mapCustomerSnapshot('users', snap, true),
      (err) => handleFirestoreError(err, OperationType.LIST, 'users')
    );

    // 3. SETTING_ADMIN & ADMIN CREDENTIALS
    const settingDoc = doc(db, 'setting_admin', 'config');
    adminSettingsUnsub = onSnapshot(
      settingDoc,
      (snap) => {
        if (snap.exists()) {
          callbacks.onSettingsChange(snap.data() as Partial<AdminSettings>);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.GET, 'setting_admin/config');
      }
    );

    // 4. TOP UP REQUESTS (Realtime for pending approvals)
    const topUpCol = collection(db, 'topup_requests');
    const qTopUp = query(topUpCol, limit(50));
    topUpRequestsUnsub = onSnapshot(
      qTopUp,
      (snapshot) => {
        const list: DriverTopUpRequest[] = [];
        snapshot.forEach((d) => {
          if (DUMMY_TOPUP_IDS.has(d.id)) return;
          list.push({ id: d.id, ...d.data() } as DriverTopUpRequest);
        });
        list.sort((a, b) => ((b.createdAt || '') > (a.createdAt || '') ? 1 : -1));
        if (callbacks.onTopUpRequestsChange) {
          callbacks.onTopUpRequestsChange(list);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'topup_requests');
      }
    );

    // 5. SALDO_HISTORY (Recent 50 transactions)
    const txCol = collection(db, 'saldo_history');
    const qTx = query(txCol, limit(50));
    saldoHistoryUnsub = onSnapshot(
      qTx,
      (snapshot) => {
        const txList: WalletTransaction[] = [];
        snapshot.forEach((d) => {
          if (DUMMY_TX_IDS.has(d.id)) return;
          txList.push({ id: d.id, ...d.data() } as WalletTransaction);
        });
        txList.sort((a, b) => ((b.date || '') > (a.date || '') ? 1 : -1));
        callbacks.onTransactionsChange(txList);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'saldo_history');
      }
    );

    // 6. KEUANGAN_ADMIN (Realtime income & expense ledger, limit 100)
    const keuanganCol = collection(db, 'keuangan_admin');
    const qKeuangan = query(keuanganCol, limit(100));
    keuanganAdminUnsub = onSnapshot(
      qKeuangan,
      (snapshot) => {
        const list: KeuanganAdminItem[] = [];
        snapshot.forEach((d) => {
          if (DUMMY_KEUANGAN_IDS.has(d.id)) return;
          const data = d.data();
          list.push({
            id: d.id,
            id_transaksi: data.id_transaksi || d.id,
            tanggal: data.tanggal || '',
            jenis: data.jenis || 'masuk',
            keterangan: data.keterangan || '',
            jumlah_rp: Number(data.jumlah_rp) || 0,
            id_order: data.id_order || '',
            nama_driver: data.nama_driver || '',
            nama_customer: data.nama_customer || '',
            isDeleted: Boolean(data.isDeleted),
            deletedAt: data.deletedAt || '',
            createdAt: data.createdAt || '',
          } as KeuanganAdminItem);
        });
        list.sort((a, b) => ((b.createdAt || b.tanggal || '') > (a.createdAt || a.tanggal || '') ? 1 : -1));
        if (callbacks.onKeuanganAdminChange) {
          callbacks.onKeuanganAdminChange(list);
        }
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, 'keuangan_admin');
      }
    );
  } catch (e) {
    console.error('Failed to start Firestore listeners:', e);
  }
}

/**
 * PAGINATED FETCH FOR ADMIN (PAGE SIZE: 20 ITEMS)
 * Required for 2,000,000 scale: Loads exactly 20 records at a time
 */
export async function fetchPaginatedOrders(
  pageSize = 20,
  lastVisibleDoc?: QueryDocumentSnapshot<DocumentData> | null
): Promise<{
  orders: Order[];
  lastDoc: QueryDocumentSnapshot<DocumentData> | null;
  hasMore: boolean;
}> {
  try {
    const ordersCol = collection(db, 'orders');
    let q = query(ordersCol, limit(pageSize));
    if (lastVisibleDoc) {
      q = query(ordersCol, startAfter(lastVisibleDoc), limit(pageSize));
    }

    const snap = await getDocs(q);
    const orders: Order[] = [];
    snap.forEach((d) => {
      const data = d.data();
      const dariVal = data.dari || data.pickupLocation || data.titik_jemput || '';
      const keVal = data.ke || data.destination || data.tujuan || '';
      const hargaVal = Number(data.harga ?? data.totalPrice ?? 270000);
      orders.push({
        id: d.id,
        ...data,
        orderNumber: data.orderNumber || data.id_order || `M3-${d.id.slice(-6)}`,
        customerId: data.customerId || data.id_customer || '',
        customerPhone: data.customerPhone || data.no_hp || data.id_customer || '',
        customerName: data.customerName || data.nama || 'Penumpang M3Car',
        pickupLocation: dariVal,
        dari: dariVal,
        destination: keVal,
        ke: keVal,
        totalPrice: hargaVal,
        harga: hargaVal,
        status: normalizeOrderStatusFromDb(data.status || data.status_db),
      } as Order);
    });

    const lastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
    const hasMore = snap.docs.length === pageSize;

    return { orders, lastDoc, hasMore };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'orders');
    return { orders: [], lastDoc: null, hasMore: false };
  }
}

/**
 * PAGINATED FETCH FOR CUSTOMERS / PENUMPANG (PAGE SIZE: 20 ITEMS)
 */
export async function fetchPaginatedCustomers(
  pageSize = 20,
  lastVisibleDoc?: QueryDocumentSnapshot<DocumentData> | null
): Promise<{
  customers: CustomerData[];
  lastDoc: QueryDocumentSnapshot<DocumentData> | null;
  hasMore: boolean;
}> {
  try {
    const custCol = collection(db, 'customers');
    let q = query(custCol, limit(pageSize));
    if (lastVisibleDoc) {
      q = query(custCol, startAfter(lastVisibleDoc), limit(pageSize));
    }

    const snap = await getDocs(q);
    const customers: CustomerData[] = [];
    snap.forEach((d) => {
      const data = d.data();
      customers.push({
        id: d.id,
        ...data,
        nama: data.nama || data.name || 'Penumpang M3Car',
        no_hp: data.no_hp || data.phone || '',
        alamat: data.alamat || 'Ujung Kulon / Jakarta',
        tanggal_daftar: data.tanggal_daftar || data.createdAt || '',
      } as CustomerData);
    });

    const lastDoc = snap.docs.length > 0 ? snap.docs[snap.docs.length - 1] : null;
    const hasMore = snap.docs.length === pageSize;

    return { customers, lastDoc, hasMore };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'customers');
    return { customers: [], lastDoc: null, hasMore: false };
  }
}

/**
 * One-time cleanup: purge all legacy dummy records from Firestore
 * (Asep Saepudin, Dedi Mulyadi, Hendra Wijaya, Ira Wijaya, dummy orders/customers/transactions)
 * and clean up any leftover docs in legacy users_driver.
 */
export async function purgeDummyRecordsFromFirestore(): Promise<void> {
  if (typeof window === 'undefined') return;
  const PURGE_FLAG = 'm3car_purged_firestore_dummy_v1';
  if (localStorage.getItem(PURGE_FLAG) === 'true') return;

  const dummyDriverNames = new Set(['asep saepudin', 'dedi mulyadi', 'hendra wijaya', 'ira wijaya', 'rudi hartono', 'jamaludin']);
  const dummyDriverIds = ['DRV-001', 'drv-2', 'drv-3'];
  const dummyOrderIds = ['ord-malaysia-931', 'ord-101'];
  const dummyCustIds = ['CUST-001', 'CUST-002', 'cust-081288990011'];
  const dummyTxIds = ['tx-001', 'tx-002'];
  const dummyTopUpIds = ['topup-req-1', 'topup-req-2'];
  const dummyKeuanganIds = ['tx-init-1', 'tx-init-2', 'tx-init-3'];

  try {
    // 1. Delete dummy IDs from drivers collection + any doc matching dummy driver names
    for (const id of dummyDriverIds) {
      try { await deleteDoc(doc(db, 'drivers', id)); } catch {}
    }
    try {
      const driversSnap = await getDocs(collection(db, 'drivers'));
      for (const d of driversSnap.docs) {
        const data = d.data();
        const nm = String(data.name || data.nama || '').trim().toLowerCase();
        if (dummyDriverNames.has(nm)) {
          await deleteDoc(doc(db, 'drivers', d.id));
        }
      }
    } catch {}

    // 2. Clean up any legacy collection documents if any still exist
    try {
      const legacySnap = await getDocs(collection(db, 'users_driver'));
      for (const d of legacySnap.docs) {
        await deleteDoc(doc(db, 'users_driver', d.id));
      }
    } catch {}

    // 3. Clean up dummy orders, customers, transactions, topup_requests, keuangan_admin
    for (const id of dummyOrderIds) {
      try { await deleteDoc(doc(db, 'orders', id)); } catch {}
    }
    for (const id of dummyCustIds) {
      try { await deleteDoc(doc(db, 'users_customer', id)); } catch {}
    }
    for (const id of dummyTxIds) {
      try { await deleteDoc(doc(db, 'saldo_history', id)); } catch {}
    }
    for (const id of dummyTopUpIds) {
      try { await deleteDoc(doc(db, 'topup_requests', id)); } catch {}
    }
    for (const id of dummyKeuanganIds) {
      try { await deleteDoc(doc(db, 'keuangan_admin', id)); } catch {}
    }

    localStorage.setItem(PURGE_FLAG, 'true');
  } catch (e) {
    console.info('Firestore dummy purge notice:', e);
  }
}

/**
 * Ensure Admin Settings document exists in Firestore without seeding any dummy users/orders
 */
export async function ensureAdminSettingsInitialized(settings: AdminSettings): Promise<void> {
  try {
    const existing = await getDoc(doc(db, 'setting_admin', 'config'));
    if (!existing.exists()) {
      await saveAdminSettingsToFirestore(settings);
    }
  } catch (e) {
    console.info('Firestore admin settings check notice:', e);
  }
}
