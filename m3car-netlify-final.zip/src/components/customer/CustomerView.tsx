import React, { useState, useMemo } from 'react';
import { useM3CarStore, normalizePhone } from '../../store/m3carStore';
import { RegionZone } from '../../types';
import {
  checkIsOutsideIndonesia,
  calculateCorridorDeviation,
  calculateOrderPricing,
  formatWaUrl,
} from '../../utils/routePricing';
import fleetHeroImg from '../../assets/images/m3car_fleet_hero_1794509944554.jpg';
import {
  MapPin,
  Navigation,
  Calendar,
  Clock,
  Users,
  Phone,
  User,
  Car,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Shield,
  ArrowRight,
  Compass,
  LogOut,
  QrCode,
  CreditCard,
  Banknote,
  LocateFixed,
} from 'lucide-react';

export const CustomerView: React.FC = () => {
  const {
    currentUser,
    orders,
    settings,
    registerCustomer,
    logout,
    createOrder,
    cancelOrderByCustomer,
  } = useM3CarStore();

  const loggedCustomer =
    currentUser && currentUser.role === 'customer' ? currentUser : null;

  // Quick Auth State (if not logged in)
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Booking Form State
  const [direction, setDirection] = useState<'UK_JKT' | 'JKT_UK'>('UK_JKT');
  const [pickupLocation, setPickupLocation] = useState('');
  const [destination, setDestination] = useState('Jakarta (Gambir / Jabodetabek)');
  const [patokan, setPatokan] = useState('');
  const [region, setRegion] = useState<RegionZone>('jakarta');
  const [date, setDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState('07:00');
  const [passengers, setPassengers] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState<'TUNAI' | 'TRANSFER_DRIVER' | 'QRIS_RTB'>('TUNAI');
  const [pickupLat, setPickupLat] = useState<number | undefined>(undefined);
  const [pickupLng, setPickupLng] = useState<number | undefined>(undefined);
  const [gpsStatus, setGpsStatus] = useState<string | null>(null);
  const [bookingAlert, setBookingAlert] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [showQrisModal, setShowQrisModal] = useState(false);

  // Direction switch helper
  const handleSelectDirection = (dir: 'UK_JKT' | 'JKT_UK') => {
    setDirection(dir);
    if (dir === 'UK_JKT') {
      setDestination('Jakarta (Jabodetabek Door-to-Door)');
    } else {
      setDestination('Ujung Kulon (Sumur / Tunggaljaya / Tamanjaya)');
    }
  };

  // Geofence & Deviation Calculation
  const geofenceCheck = useMemo(
    () =>
      checkIsOutsideIndonesia({
        address: pickupLocation,
        lat: pickupLat,
        lng: pickupLng,
      }),
    [pickupLocation, pickupLat, pickupLng]
  );

  const deviationInfo = useMemo(
    () =>
      calculateCorridorDeviation({
        address: pickupLocation,
        lat: pickupLat,
        lng: pickupLng,
      }),
    [pickupLocation, pickupLat, pickupLng]
  );

  const pricing = useMemo(() => {
    const basePerPerson = settings.pricePerPerson || 270000;
    const calc = calculateOrderPricing(passengers, deviationInfo.deviationKm);
    const customBase = Math.max(1, passengers) * basePerPerson;
    return {
      ...calc,
      pricePerPerson: basePerPerson,
      basePrice: customBase,
      totalPrice: customBase + calc.deviationFee,
    };
  }, [passengers, deviationInfo.deviationKm, settings.pricePerPerson]);

  const handleUseGps = () => {
    if (!navigator.geolocation) {
      setGpsStatus('Browser tidak mendukung GPS.');
      return;
    }
    setGpsStatus('Mengambil koordinat GPS...');
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));
        setPickupLat(lat);
        setPickupLng(lng);
        if (!pickupLocation.trim()) {
          setPickupLocation(`Titik GPS (${lat}, ${lng})`);
        }
        setGpsStatus(`Koordinat GPS aktif (${lat}, ${lng})`);
      },
      () => {
        setGpsStatus('Gagal mengambil lokasi GPS. Silakan ketik alamat manual.');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const handleCustomerAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (!custName.trim()) {
      setAuthError('Nama lengkap wajib diisi.');
      return;
    }
    const res = registerCustomer({
      name: custName.trim(),
      phone: custPhone.trim(),
    });
    if (!res.success) {
      setAuthError(res.message || 'Gagal masuk.');
    }
  };

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingAlert(null);

    const activeName = loggedCustomer?.name || custName.trim();
    const activePhone = loggedCustomer?.phone || custPhone.trim();

    if (!activeName || !activePhone) {
      setBookingAlert({ type: 'error', text: 'Silakan isi Nama dan No HP WhatsApp (+62) terlebih dahulu.' });
      return;
    }

    // Auto-register customer if not yet logged in
    if (!loggedCustomer) {
      const regRes = registerCustomer({ name: activeName, phone: activePhone });
      if (!regRes.success) {
        setBookingAlert({ type: 'error', text: regRes.message || 'Nomor HP harus nomor Indonesia (+62).' });
        return;
      }
    }

    if (!pickupLocation.trim()) {
      setBookingAlert({ type: 'error', text: 'Titik jemput wajib diisi.' });
      return;
    }

    if (geofenceCheck.isOutsideIndonesia) {
      setBookingAlert({ type: 'error', text: geofenceCheck.warningText });
      return;
    }

    const created = createOrder({
      customerName: activeName,
      customerPhone: activePhone,
      pickupLocation: pickupLocation.trim(),
      destination: destination.trim(),
      route: direction === 'UK_JKT' ? 'Ujung Kulon -> Jakarta' : 'Jakarta -> Ujung Kulon',
      patokan: patokan.trim(),
      date,
      time,
      passengers,
      region,
      pricePerPerson: pricing.pricePerPerson,
      basePrice: pricing.basePrice,
      deviationKm: pricing.deviationKm,
      deviationFee: pricing.deviationFee,
      totalPrice: pricing.totalPrice,
      pickupLat,
      pickupLng,
      paymentMethod,
    });

    setPickupLocation('');
    setPatokan('');
    setBookingAlert({
      type: 'success',
      text: `Pesanan ${created.orderNumber} berhasil dibuat! Sistem sedang mencari driver terdekat.`,
    });
  };

  const myOrders = useMemo(() => {
    if (!loggedCustomer) return [];
    const normCustPhone = normalizePhone(loggedCustomer.phone);
    return orders.filter(
      (o) => !o.isDeleted && normalizePhone(o.customerPhone) === normCustPhone
    );
  }, [orders, loggedCustomer]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
      {/* Hero Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between space-y-5 shadow-2xl">
          <div className="space-y-3">
            <div className="text-xs font-bold text-red-400 uppercase tracking-wider flex items-center gap-2">
              <Compass className="w-4 h-4" />
              <span>{settings.siteContent?.subTagline || 'Travel Antar Jemput Ujung Kulon - Jakarta 24 Jam'}</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-white leading-tight [text-wrap:balance]">
              {settings.siteContent?.tagline || 'Jemput Cepat, Sampai Selamat'}
            </h1>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed max-w-2xl">
              {settings.siteContent?.welcomeText ||
                'CV. ROYAL TRANS BERKAH GROUP melayani antar jemput door-to-door rute Jakarta - Ujung Kulon via Tol Tangerang-Merak & Tol Serang-Panimbang dengan armada prima dan mitra driver terverifikasi KTP & SIM A.'}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3 pt-4 border-t border-neutral-800 text-xs">
            <div>
              <span className="text-[11px] text-neutral-400 block">Tarif Normal</span>
              <span className="text-sm sm:text-base font-black text-white tabular-nums">
                Rp {(settings.pricePerPerson || 270000).toLocaleString('id-ID')}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-neutral-400 block">Estimasi Tol</span>
              <span className="text-sm sm:text-base font-black text-red-400">
                {settings.siteContent?.travelTimeEta || '6 Jam 30 Menit'}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-neutral-400 block">Layanan</span>
              <span className="text-sm sm:text-base font-black text-emerald-400">24 Jam</span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-3xl overflow-hidden border border-neutral-800 bg-neutral-900 relative min-h-[220px] shadow-2xl">
          <img
            src={settings.siteContent?.bannerUrl || fleetHeroImg}
            alt="Armada Eksekutif M3CAR Travel"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover lg:h-full"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/25 to-transparent flex flex-col justify-end p-5">
            <div className="text-xs font-bold text-red-400 uppercase tracking-wider">
              Door to Door Service
            </div>
            <div className="text-sm font-black text-white mt-0.5">
              {settings.siteContent?.tollRouteDesc || 'Tol Jakarta-Merak + Tol Serang-Panimbang 83,6 km'}
            </div>
          </div>
        </div>
      </div>

      {/* Customer Identity Bar or Quick Sign-In */}
      {loggedCustomer ? (
        <div className="bg-neutral-900 border border-neutral-800 rounded-2xl px-5 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs">
            <div className="w-9 h-9 rounded-xl bg-red-600/15 border border-red-600/40 flex items-center justify-center">
              <User className="w-4 h-4 text-red-500" />
            </div>
            <div>
              <span className="font-black text-white text-sm block">{loggedCustomer.name}</span>
              <span className="text-neutral-400 font-mono">{loggedCustomer.phone}</span>
            </div>
          </div>

          <button
            type="button"
            onClick={logout}
            className="px-3.5 py-2 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 rounded-xl text-xs font-bold text-neutral-300 flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-red-400" />
            <span>Ganti Akun</span>
          </button>
        </div>
      ) : (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-2 text-sm font-black text-white">
            <User className="w-4 h-4 text-red-500" />
            <span>Identitas Penumpang (Daftar / Masuk Cepat Tanpa Password)</span>
          </div>
          {authError && (
            <div className="p-3 bg-red-950/70 border border-red-700 rounded-xl text-xs font-bold text-red-200">
              {authError}
            </div>
          )}
          <form onSubmit={handleCustomerAuth} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input
              type="text"
              value={custName}
              onChange={(e) => setCustName(e.target.value)}
              placeholder="Nama Lengkap Penumpang"
              className="px-4 py-3 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs text-white focus:outline-none"
            />
            <input
              type="tel"
              value={custPhone}
              onChange={(e) => setCustPhone(e.target.value)}
              placeholder="No WhatsApp (+62 / 08...)"
              className="px-4 py-3 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs font-mono text-white focus:outline-none"
            />
            <button
              type="submit"
              className="py-3 px-5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-black cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Masuk / Simpan Profil</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* Main Content Split: Booking Form + Active Orders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Booking Form */}
        <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-3xl p-6 space-y-5 shadow-xl">
          <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
            <div>
              <h2 className="text-lg font-black text-white">Pesan Travel Door-to-Door</h2>
              <p className="text-xs text-neutral-400">Isi titik jemput &amp; tujuan untuk memanggil driver terdekat</p>
            </div>
          </div>

          {bookingAlert && (
            <div
              className={`p-4 rounded-2xl text-xs font-bold flex items-start gap-2.5 ${
                bookingAlert.type === 'success'
                  ? 'bg-emerald-950 border border-emerald-700 text-emerald-200'
                  : 'bg-red-950 border border-red-700 text-red-200'
              }`}
            >
              {bookingAlert.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              )}
              <span>{bookingAlert.text}</span>
            </div>
          )}

          {/* Direction Selector */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-neutral-950 border border-neutral-800 rounded-2xl">
            <button
              type="button"
              onClick={() => handleSelectDirection('UK_JKT')}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                direction === 'UK_JKT' ? 'bg-red-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Ujung Kulon &rarr; Jakarta
            </button>
            <button
              type="button"
              onClick={() => handleSelectDirection('JKT_UK')}
              className={`py-2.5 px-3 rounded-xl text-xs font-bold cursor-pointer transition-colors ${
                direction === 'JKT_UK' ? 'bg-red-600 text-white' : 'text-neutral-400 hover:text-white'
              }`}
            >
              Jakarta &rarr; Ujung Kulon
            </button>
          </div>

          <form onSubmit={handleCreateOrder} className="space-y-4">
            {!loggedCustomer && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">Nama Penumpang</label>
                  <input
                    type="text"
                    required
                    value={custName}
                    onChange={(e) => setCustName(e.target.value)}
                    placeholder="Nama Lengkap"
                    className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs text-white focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-neutral-300 mb-1">No HP WhatsApp</label>
                  <input
                    type="tel"
                    required
                    value={custPhone}
                    onChange={(e) => setCustPhone(e.target.value)}
                    placeholder="0812xxxxxxxx"
                    className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs font-mono text-white focus:outline-none"
                  />
                </div>
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-neutral-300">Alamat Titik Jemput (Door-to-Door)</label>
                <button
                  type="button"
                  onClick={handleUseGps}
                  className="text-[11px] font-bold text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer"
                >
                  <LocateFixed className="w-3.5 h-3.5" />
                  <span>Gunakan GPS</span>
                </button>
              </div>
              <input
                type="text"
                required
                value={pickupLocation}
                onChange={(e) => setPickupLocation(e.target.value)}
                placeholder="Contoh: Desa Tunggaljaya, Sumur / Stasiun Gambir Jakarta Pusat"
                className="w-full px-4 py-3 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs text-white focus:outline-none"
              />
              {gpsStatus && <p className="text-[11px] text-neutral-400 mt-1">{gpsStatus}</p>}
              {geofenceCheck.isOutsideIndonesia && (
                <p className="text-xs font-bold text-red-400 mt-1">{geofenceCheck.warningText}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">Alamat Tujuan</label>
                <input
                  type="text"
                  required
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1">Wilayah Layanan</label>
                <select
                  value={region}
                  onChange={(e) => setRegion(e.target.value as RegionZone)}
                  className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs text-white focus:outline-none"
                >
                  <option value="jakarta">DKI Jakarta</option>
                  <option value="tangerang_depok">Tangerang / Depok</option>
                  <option value="bogor_bekasi">Bogor / Bekasi</option>
                  <option value="luar_jabodetabek">Banten / Ujung Kulon</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-300 mb-1">Patokan Rumah / Catatan (Opsional)</label>
              <input
                type="text"
                value={patokan}
                onChange={(e) => setPatokan(e.target.value)}
                placeholder="Contoh: Depan Masjid Al-Ikhlas, pagar hitam"
                className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 focus:border-red-500 rounded-xl text-xs text-white focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-red-500" />
                  <span>Tanggal</span>
                </label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:border-red-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-red-500" />
                  <span>Jam</span>
                </label>
                <input
                  type="time"
                  required
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:border-red-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-neutral-300 mb-1 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-red-500" />
                  <span>Kursi</span>
                </label>
                <select
                  value={passengers}
                  onChange={(e) => setPassengers(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:border-red-500 focus:outline-none"
                >
                  {[1, 2, 3, 4, 5, 6, 7].map((n) => (
                    <option key={n} value={n}>
                      {n} Orang
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-neutral-300">Metode Pembayaran</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'TUNAI', label: 'Tunai ke Driver', icon: Banknote },
                  { id: 'TRANSFER_DRIVER', label: 'Transfer Bank', icon: CreditCard },
                  { id: 'QRIS_RTB', label: 'QRIS RTB', icon: QrCode },
                ].map((m) => {
                  const Icon = m.icon;
                  return (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => setPaymentMethod(m.id as any)}
                      className={`py-2.5 px-2 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                        paymentMethod === m.id
                          ? 'bg-red-600 border-red-500 text-white'
                          : 'bg-neutral-950 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{m.label}</span>
                    </button>
                  );
                })}
              </div>
              {paymentMethod === 'QRIS_RTB' && (
                <button
                  type="button"
                  onClick={() => setShowQrisModal(true)}
                  className="text-xs font-bold text-red-400 hover:text-red-300 underline cursor-pointer"
                >
                  Tampilkan Kode QRIS Resmi M3CAR
                </button>
              )}
            </div>

            {/* Price Summary */}
            <div className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 space-y-2 text-xs">
              <div className="flex items-center justify-between text-neutral-400">
                <span>
                  Tarif Normal ({passengers} x Rp {pricing.pricePerPerson.toLocaleString('id-ID')})
                </span>
                <span className="font-bold text-white tabular-nums">
                  Rp {pricing.basePrice.toLocaleString('id-ID')}
                </span>
              </div>
              {pricing.deviationKm > 0 && (
                <div className="flex items-center justify-between text-amber-400">
                  <span>Deviasi Jalur ({pricing.deviationKm} km)</span>
                  <span className="font-bold tabular-nums">
                    +Rp {pricing.deviationFee.toLocaleString('id-ID')}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
                <span className="font-black text-white text-sm">Total Pembayaran</span>
                <span className="font-black text-emerald-400 text-lg tabular-nums">
                  Rp {pricing.totalPrice.toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={geofenceCheck.isOutsideIndonesia}
              className="w-full py-3.5 px-6 bg-red-600 hover:bg-red-500 text-white rounded-2xl font-black text-sm shadow-xl shadow-red-900/40 cursor-pointer transition-all disabled:opacity-40"
            >
              Pesan Travel Sekarang
            </button>
          </form>
        </div>

        {/* Right: Active Orders & Tracking */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 space-y-4 shadow-xl">
            <h2 className="text-base font-black text-white flex items-center gap-2">
              <Navigation className="w-4 h-4 text-red-500" />
              <span>Status Perjalanan Saya ({myOrders.length})</span>
            </h2>

            {!loggedCustomer ? (
              <div className="text-xs text-neutral-400 py-6 text-center">
                Masuk atau buat pesanan terlebih dahulu untuk memantau posisi driver secara realtime.
              </div>
            ) : myOrders.length === 0 ? (
              <div className="text-xs text-neutral-400 py-6 text-center">
                Belum ada riwayat pesanan atas nomor <span className="font-mono text-white">{loggedCustomer.phone}</span>.
              </div>
            ) : (
              <div className="space-y-3">
                {myOrders.map((order) => (
                  <div
                    key={order.id}
                    className="bg-neutral-950 border border-neutral-800 rounded-2xl p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-mono font-bold text-red-400">{order.orderNumber}</span>
                      <span
                        className={`font-bold ${
                          order.status === 'SELESAI'
                            ? 'text-emerald-400'
                            : order.status === 'DIBATALKAN'
                            ? 'text-red-400'
                            : 'text-amber-400'
                        }`}
                      >
                        {order.status}
                      </span>
                    </div>

                    <div className="text-xs space-y-1">
                      <div className="text-neutral-300">
                        <MapPin className="w-3.5 h-3.5 text-red-500 inline mr-1" />
                        <span className="font-semibold text-white">{order.pickupLocation}</span>
                      </div>
                      <div className="text-neutral-400">
                        Ke: <span className="text-neutral-200">{order.destination}</span>
                      </div>
                      <div className="text-neutral-400">
                        {order.date} &middot; {order.time} &middot; {order.passengers} Kursi &middot;{' '}
                        <span className="text-emerald-400 font-bold tabular-nums">
                          Rp {(order.totalPrice || 270000).toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>

                    {order.driverName && (
                      <div className="bg-neutral-900 border border-neutral-800 rounded-xl p-3 flex items-center justify-between gap-2 text-xs">
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <Car className="w-3.5 h-3.5 text-red-500" />
                            <span>{order.driverName}</span>
                          </div>
                          <div className="text-[11px] text-neutral-400">
                            {order.driverCar} &middot;{' '}
                            <span className="font-mono text-red-400">{order.driverPlate}</span>
                          </div>
                        </div>
                        {order.driverPhone && (
                          <a
                            href={formatWaUrl(
                              order.driverPhone,
                              `Halo Pak ${order.driverName}, saya penumpang M3CAR (${order.orderNumber}).`
                            )}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-bold flex items-center gap-1"
                          >
                            <Phone className="w-3 h-3" />
                            <span>Chat Driver</span>
                          </a>
                        )}
                      </div>
                    )}

                    {order.status === 'MENCARI_DRIVER' && (
                      <button
                        type="button"
                        onClick={() => cancelOrderByCustomer(order.id)}
                        className="w-full py-2 bg-neutral-900 hover:bg-red-950 border border-neutral-800 hover:border-red-800 text-neutral-300 hover:text-red-300 rounded-xl text-xs font-bold cursor-pointer transition-colors"
                      >
                        Batalkan Pesanan
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 text-xs space-y-2">
            <div className="font-black text-white flex items-center gap-2">
              <Shield className="w-4 h-4 text-red-500" />
              <span>Bantuan Admin 24 Jam</span>
            </div>
            <p className="text-neutral-400">
              Butuh bantuan cepat atau jadwal khusus? Hubungi Admin Pusat CV. Royal Trans Berkah Group.
            </p>
            <a
              href={formatWaUrl(
                settings.adminPhone || '085811594114',
                'Halo Admin M3CAR, saya ingin menanyakan jadwal travel Ujung Kulon - Jakarta.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-white rounded-xl font-bold"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>WhatsApp Admin ({settings.adminPhone || '085811594114'})</span>
            </a>
          </div>
        </div>
      </div>

      {/* QRIS Modal */}
      {showQrisModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-5 max-w-sm w-full space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black text-white">QRIS Resmi M3CAR (RTB Group)</h3>
              <button
                type="button"
                onClick={() => setShowQrisModal(false)}
                className="p-1.5 bg-neutral-800 rounded-full text-neutral-400 hover:text-white cursor-pointer"
              >
                <XCircle className="w-4 h-4" />
              </button>
            </div>
            <img
              src="/assets/aistudio/IMG-20261104-WA0014_1b3b07c0.jpg"
              alt="QRIS RTB Group Travel Sumur"
              className="w-full rounded-2xl border border-neutral-800"
            />
          </div>
        </div>
      )}
    </div>
  );
};
