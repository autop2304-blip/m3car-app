import React, { useState, useMemo } from 'react';
import { useM3CarStore } from '../../store/m3carStore';
import { DriverTopUpRequest, KeuanganAdminItem, WalletTransaction } from '../../types';
import {
  Wallet,
  Banknote,
  ArrowLeftRight,
  Percent,
  CheckCircle2,
  XCircle,
  Plus,
  Trash2,
  Eye,
  X,
} from 'lucide-react';

export const AdminFinanceSection: React.FC = () => {
  const {
    orders,
    drivers,
    transactions,
    topUpRequests,
    keuanganAdmin,
    approveTopUpRequest,
    rejectTopUpRequest,
    deleteTopUpRequest,
    deleteTransaction,
    deleteKeuanganItem,
    addKeuanganTransaction,
  } = useM3CarStore();

  const [subTab, setSubTab] = useState<'ringkasan' | 'topup' | 'riwayat'>('ringkasan');
  const [paymentFilter, setPaymentFilter] = useState<'ALL' | 'TUNAI' | 'TRANSFER'>('ALL');

  // Modals
  const [receiptPreview, setReceiptPreview] = useState<DriverTopUpRequest | null>(null);
  const [rejectTopUpTarget, setRejectTopUpTarget] = useState<DriverTopUpRequest | null>(null);
  const [rejectReason, setRejectReason] = useState('Bukti transfer tidak valid / dana belum masuk');
  const [isAddKasOpen, setIsAddKasOpen] = useState(false);
  const [kasForm, setKasForm] = useState<{ jenis: 'masuk' | 'keluar'; jumlah: number; keterangan: string }>({
    jenis: 'masuk',
    jumlah: 100000,
    keterangan: 'Pencatatan Kas M3CAR',
  });
  const [txToDelete, setTxToDelete] = useState<WalletTransaction | null>(null);
  const [keuanganToDelete, setKeuanganToDelete] = useState<KeuanganAdminItem | null>(null);

  const activeOrders = useMemo(() => orders.filter((o) => !o.isDeleted), [orders]);
  const activeDrivers = useMemo(() => drivers.filter((d) => !d.isDeleted), [drivers]);
  const activeKeuangan = useMemo(() => keuanganAdmin.filter((k) => !k.isDeleted), [keuanganAdmin]);
  const activeTopUps = useMemo(() => topUpRequests.filter((r) => !r.isDeleted), [topUpRequests]);

  // Real financial metrics from Firebase collections
  const completedOrPaidOrders = useMemo(
    () => activeOrders.filter((o) => o.status === 'SELESAI' || o.paymentStatus === 'LUNAS'),
    [activeOrders]
  );

  const totalTransaksiNominal = useMemo(
    () =>
      completedOrPaidOrders.reduce((sum, o) => sum + (Number(o.totalPrice ?? o.harga) || 0), 0),
    [completedOrPaidOrders]
  );

  const pendapatanAplikasiKomisi = useMemo(
    () =>
      completedOrPaidOrders.reduce((sum, o) => {
        const price = Number(o.totalPrice ?? o.harga) || 0;
        const comm = Number(o.commissionAmount) || Math.round(price * (o.commissionRate || 0.12));
        return sum + comm;
      }, 0),
    [completedOrPaidOrders]
  );

  const totalSaldoDriver = useMemo(
    () => activeDrivers.reduce((sum, d) => sum + Number(d.saldo ?? d.balance ?? 0), 0),
    [activeDrivers]
  );

  const pembayaranTunai = useMemo(
    () =>
      completedOrPaidOrders
        .filter((o) => (o.paymentMethod || 'TUNAI') === 'TUNAI')
        .reduce((sum, o) => sum + (Number(o.totalPrice ?? o.harga) || 0), 0),
    [completedOrPaidOrders]
  );

  const pembayaranTransfer = useMemo(() => {
    const orderTransfers = completedOrPaidOrders
      .filter((o) =>
        ['TRANSFER_DRIVER', 'QRIS_RTB', 'M3CAR_PAY'].includes(o.paymentMethod || '')
      )
      .reduce((sum, o) => sum + (Number(o.totalPrice ?? o.harga) || 0), 0);
    const approvedTopUps = activeTopUps
      .filter((r) => r.status === 'BERHASIL')
      .reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
    return orderTransfers + approvedTopUps;
  }, [completedOrPaidOrders, activeTopUps]);

  const filteredOrderTransactions = useMemo(() => {
    return completedOrPaidOrders.filter((o) => {
      const m = o.paymentMethod || 'TUNAI';
      if (paymentFilter === 'TUNAI') return m === 'TUNAI';
      if (paymentFilter === 'TRANSFER') return m !== 'TUNAI';
      return true;
    });
  }, [completedOrPaidOrders, paymentFilter]);

  const handleConfirmRejectTopUp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectTopUpTarget) return;
    rejectTopUpRequest(rejectTopUpTarget.id, rejectReason.trim() || 'Bukti transfer ditolak');
    setRejectTopUpTarget(null);
  };

  const handleAddKas = (e: React.FormEvent) => {
    e.preventDefault();
    if (kasForm.jumlah <= 0) return;
    addKeuanganTransaction({
      jenis: kasForm.jenis,
      jumlah_rp: Number(kasForm.jumlah),
      keterangan: kasForm.keterangan.trim() || 'Transaksi Manual Admin',
    });
    setIsAddKasOpen(false);
    setKasForm({ jenis: 'masuk', jumlah: 100000, keterangan: 'Pencatatan Kas M3CAR' });
  };

  return (
    <div className="space-y-6">
      {/* 5 Real Financial KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Transaksi</span>
            <Wallet className="w-4 h-4 text-[#0F294A]" />
          </div>
          <div className="text-xl font-extrabold text-slate-950 font-mono tabular-nums mt-2">
            Rp {totalTransaksiNominal.toLocaleString('id-ID')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            {completedOrPaidOrders.length} pesanan selesai / lunas
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Pendapatan Aplikasi</span>
            <Percent className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-extrabold text-emerald-700 font-mono tabular-nums mt-2">
            Rp {pendapatanAplikasiKomisi.toLocaleString('id-ID')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Akumulasi komisi aplikasi</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Total Saldo Driver</span>
            <Wallet className="w-4 h-4 text-[#0F294A]" />
          </div>
          <div className="text-xl font-extrabold text-[#0F294A] font-mono tabular-nums mt-2">
            Rp {totalSaldoDriver.toLocaleString('id-ID')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">{activeDrivers.length} akun driver</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Pembayaran Tunai</span>
            <Banknote className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-extrabold text-slate-950 font-mono tabular-nums mt-2">
            Rp {pembayaranTunai.toLocaleString('id-ID')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Transaksi tunai order</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Pembayaran Transfer</span>
            <ArrowLeftRight className="w-4 h-4 text-blue-700" />
          </div>
          <div className="text-xl font-extrabold text-slate-950 font-mono tabular-nums mt-2">
            Rp {pembayaranTransfer.toLocaleString('id-ID')}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Transfer order &amp; top-up</div>
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="bg-white border border-slate-200 rounded-xl p-2 flex items-center justify-between flex-wrap gap-2 shadow-sm">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <button
            type="button"
            onClick={() => setSubTab('ringkasan')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer whitespace-nowrap ${
              subTab === 'ringkasan'
                ? 'bg-[#0F294A] text-white'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100'
            }`}
          >
            Ringkasan Transaksi &amp; Saldo Driver
          </button>
          <button
            type="button"
            onClick={() => setSubTab('topup')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer whitespace-nowrap ${
              subTab === 'topup'
                ? 'bg-[#0F294A] text-white'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100'
            }`}
          >
            Permintaan Top Up ({activeTopUps.filter((r) => r.status === 'MENUNGGU').length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab('riwayat')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold cursor-pointer whitespace-nowrap ${
              subTab === 'riwayat'
                ? 'bg-[#0F294A] text-white'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100'
            }`}
          >
            Riwayat Mutasi &amp; Buku Kas
          </button>
        </div>

        <button
          type="button"
          onClick={() => setIsAddKasOpen(true)}
          className="px-3.5 py-2 rounded-lg bg-[#070B14] hover:bg-[#0F294A] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Catat Transaksi Kas</span>
        </button>
      </div>

      {/* Sub-Tab 1: Ringkasan Order Transaksi + Saldo Driver */}
      {subTab === 'ringkasan' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Order Transactions & Payment Filter */}
          <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h4 className="text-sm font-bold text-slate-950">Transaksi Pesanan &amp; Komisi</h4>
              <div className="flex items-center gap-1 text-[11px] font-bold">
                {(['ALL', 'TUNAI', 'TRANSFER'] as const).map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setPaymentFilter(k)}
                    className={`px-2.5 py-1 rounded-md cursor-pointer ${
                      paymentFilter === k
                        ? 'bg-[#0F294A] text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {k === 'ALL' ? 'Semua' : k === 'TUNAI' ? 'Tunai' : 'Transfer / QRIS'}
                  </button>
                ))}
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-bold">
                    <th className="py-3 px-4">Order</th>
                    <th className="py-3 px-4">Penumpang &amp; Driver</th>
                    <th className="py-3 px-4">Metode</th>
                    <th className="py-3 px-4 text-right">Total</th>
                    <th className="py-3 px-4 text-right">Komisi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredOrderTransactions.map((o) => {
                    const price = Number(o.totalPrice ?? o.harga ?? 0);
                    const comm =
                      Number(o.commissionAmount) || Math.round(price * (o.commissionRate || 0.12));
                    return (
                      <tr key={o.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4">
                          <div className="font-mono font-bold text-slate-900">{o.orderNumber}</div>
                          <div className="text-[11px] text-slate-500">{o.date}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{o.customerName}</div>
                          <div className="text-[11px] text-slate-500">Driver: {o.driverName || '-'}</div>
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] font-bold text-slate-700">
                          {o.paymentMethod || 'TUNAI'}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-950 tabular-nums">
                          Rp {price.toLocaleString('id-ID')}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-700 tabular-nums">
                          Rp {comm.toLocaleString('id-ID')}
                        </td>
                      </tr>
                    );
                  })}
                  {filteredOrderTransactions.length === 0 && (
                    <tr>
                      <td colSpan={5} className="text-center py-8 text-slate-500">
                        Belum ada transaksi pesanan selesai atau lunas.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Driver Balance Breakdown */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200">
              <h4 className="text-sm font-bold text-slate-950">Saldo per Driver</h4>
            </div>
            <div className="divide-y divide-slate-100 max-h-[420px] overflow-y-auto">
              {activeDrivers.map((d) => (
                <div key={d.id} className="px-4 py-3 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-bold text-slate-900 truncate">{d.name}</div>
                    <div className="font-mono text-[11px] text-slate-500">{d.plateNumber}</div>
                  </div>
                  <div className="font-mono font-bold text-[#0F294A] tabular-nums shrink-0">
                    Rp {Number(d.saldo ?? d.balance ?? 0).toLocaleString('id-ID')}
                  </div>
                </div>
              ))}
              {activeDrivers.length === 0 && (
                <div className="text-center py-8 text-xs text-slate-500">Belum ada data driver.</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Top Up Requests */}
      {subTab === 'topup' && (
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-bold">
                  <th className="py-3.5 px-4">Waktu</th>
                  <th className="py-3.5 px-4">Driver</th>
                  <th className="py-3.5 px-4 text-right">Nominal</th>
                  <th className="py-3.5 px-4">Bukti Transfer</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {activeTopUps.map((req) => (
                  <tr key={req.id} className="hover:bg-slate-50/70">
                    <td className="py-3.5 px-4 font-mono text-slate-600">{req.createdAt}</td>
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-950">{req.driverName}</div>
                      <div className="font-mono text-[11px] text-slate-500">{req.driverPlate}</div>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-950 tabular-nums">
                      Rp {Number(req.amount || 0).toLocaleString('id-ID')}
                    </td>
                    <td className="py-3.5 px-4">
                      {req.receiptPhotoUrl ? (
                        <button
                          type="button"
                          onClick={() => setReceiptPreview(req)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5 text-[#0F294A]" />
                          <span>Lihat Bukti</span>
                        </button>
                      ) : (
                        <span className="text-slate-400">Tanpa Bukti</span>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-bold ${
                          req.status === 'BERHASIL'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : req.status === 'MENUNGGU'
                            ? 'bg-amber-50 text-amber-800 border border-amber-200'
                            : 'bg-red-50 text-red-700 border border-red-200'
                        }`}
                      >
                        {req.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {req.status === 'MENUNGGU' && (
                          <>
                            <button
                              type="button"
                              onClick={() => approveTopUpRequest(req.id)}
                              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Setujui</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setRejectReason('Bukti transfer tidak valid / dana belum masuk');
                                setRejectTopUpTarget(req);
                              }}
                              className="px-2.5 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              <span>Tolak</span>
                            </button>
                          </>
                        )}
                        <button
                          type="button"
                          onClick={() => deleteTopUpRequest(req.id)}
                          className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 cursor-pointer"
                          title="Hapus"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {activeTopUps.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-slate-500">
                      Belum ada permintaan top-up saldo driver.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sub-Tab 3: Riwayat Mutasi Saldo & Buku Kas */}
      {subTab === 'riwayat' && (
        <div className="space-y-6">
          {/* Buku Kas Admin */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200">
              <h4 className="text-sm font-bold text-slate-950">Buku Kas Keuangan (keuangan_admin)</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-bold">
                    <th className="py-3 px-4">ID Transaksi</th>
                    <th className="py-3 px-4">Tanggal</th>
                    <th className="py-3 px-4">Jenis</th>
                    <th className="py-3 px-4">Keterangan</th>
                    <th className="py-3 px-4 text-right">Jumlah (Rp)</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeKeuangan.map((k) => (
                    <tr key={k.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4 font-mono font-bold text-slate-800">{k.id_transaksi || k.id}</td>
                      <td className="py-3 px-4 text-slate-600">{k.tanggal}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            k.jenis === 'masuk'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-red-50 text-red-700 border border-red-200'
                          }`}
                        >
                          {k.jenis}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-800">{k.keterangan}</td>
                      <td
                        className={`py-3 px-4 text-right font-mono font-bold tabular-nums ${
                          k.jenis === 'masuk' ? 'text-emerald-700' : 'text-red-700'
                        }`}
                      >
                        {k.jenis === 'masuk' ? '+' : '-'} Rp {Number(k.jumlah_rp || 0).toLocaleString('id-ID')}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => setKeuanganToDelete(k)}
                          className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {activeKeuangan.length === 0 && (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-slate-500">
                        Belum ada catatan buku kas.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mutasi Saldo Driver */}
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200">
              <h4 className="text-sm font-bold text-slate-950">Riwayat Mutasi Saldo Driver (saldo_history)</h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[11px] font-bold">
                    <th className="py-3 px-4">Waktu</th>
                    <th className="py-3 px-4">Driver</th>
                    <th className="py-3 px-4">Jenis</th>
                    <th className="py-3 px-4">Keterangan</th>
                    <th className="py-3 px-4 text-right">Nominal</th>
                    <th className="py-3 px-4 text-right">Saldo Akhir</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.map((tx) => {
                    const drv = drivers.find((d) => d.id === tx.driverId);
                    return (
                      <tr key={tx.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono text-slate-600">{tx.date}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{drv?.name || tx.driverId}</td>
                        <td className="py-3 px-4 font-mono text-[11px]">{tx.type}</td>
                        <td className="py-3 px-4 text-slate-700">{tx.description}</td>
                        <td
                          className={`py-3 px-4 text-right font-mono font-bold tabular-nums ${
                            tx.amount >= 0 ? 'text-emerald-700' : 'text-red-700'
                          }`}
                        >
                          {tx.amount >= 0 ? '+' : ''}Rp {tx.amount.toLocaleString('id-ID')}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                          Rp {Number(tx.balanceAfter || 0).toLocaleString('id-ID')}
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={() => setTxToDelete(tx)}
                            className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {transactions.length === 0 && (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-slate-500">
                        Belum ada mutasi saldo driver.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Receipt Preview Modal */}
      {receiptPreview && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="bg-[#0B162C] text-white px-5 py-4 flex items-center justify-between">
              <h4 className="font-bold text-sm">Bukti Transfer — {receiptPreview.driverName}</h4>
              <button
                type="button"
                onClick={() => setReceiptPreview(null)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-300 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              {receiptPreview.receiptPhotoUrl && (
                <img
                  src={receiptPreview.receiptPhotoUrl}
                  alt="Bukti Transfer"
                  className="w-full max-h-96 object-contain rounded-lg border border-slate-200 bg-slate-50"
                />
              )}
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-500">Nominal Permintaan:</span>
                <span className="font-mono font-extrabold text-slate-950">
                  Rp {Number(receiptPreview.amount || 0).toLocaleString('id-ID')}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reject Top Up Modal */}
      {rejectTopUpTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleConfirmRejectTopUp}
            className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl"
          >
            <h4 className="text-base font-bold text-slate-950">Tolak Permintaan Top Up</h4>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Alasan Penolakan</label>
              <textarea
                rows={3}
                required
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full p-3 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-950 focus:outline-none focus:border-[#0F294A]"
              />
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setRejectTopUpTarget(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
              >
                Tolak Top Up
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Manual Kas Modal */}
      {isAddKasOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleAddKas}
            className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl"
          >
            <h4 className="text-base font-bold text-slate-950">Catat Transaksi Kas Manual</h4>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Jenis Transaksi</label>
              <select
                value={kasForm.jenis}
                onChange={(e) => setKasForm({ ...kasForm, jenis: e.target.value as 'masuk' | 'keluar' })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold text-slate-950"
              >
                <option value="masuk">Kas Masuk</option>
                <option value="keluar">Kas Keluar</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Jumlah (Rp)</label>
              <input
                type="number"
                required
                min={1000}
                value={kasForm.jumlah}
                onChange={(e) => setKasForm({ ...kasForm, jumlah: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm font-mono font-bold text-slate-950"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Keterangan</label>
              <input
                type="text"
                required
                value={kasForm.keterangan}
                onChange={(e) => setKasForm({ ...kasForm, keterangan: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-950"
              />
            </div>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddKasOpen(false)}
                className="px-4 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#0F294A] hover:bg-[#173B6B] text-white text-xs font-bold cursor-pointer"
              >
                Simpan Transaksi
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Kas / Transaction Confirmation Modals */}
      {keuanganToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-slate-950">Hapus Catatan Kas?</h4>
            <p className="text-xs text-slate-600">{keuanganToDelete.keterangan}</p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setKeuanganToDelete(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteKeuanganItem(keuanganToDelete.id);
                  setKeuanganToDelete(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-600 text-white text-xs font-bold cursor-pointer"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}

      {txToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
            <h4 className="text-base font-bold text-slate-950">Hapus Mutasi Saldo?</h4>
            <p className="text-xs text-slate-600">{txToDelete.description}</p>
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setTxToDelete(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 text-slate-700 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteTransaction(txToDelete.id);
                  setTxToDelete(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-600 text-white text-xs font-bold cursor-pointer"
              >
                Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
