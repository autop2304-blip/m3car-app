/**
 * M3CAR Central Application Store
 * Reactive state with localStorage persistence & simulated dispatch timers.
 * Integrated with Firebase Realtime Database & Firebase Auth.
 */

import { useState, useEffect, useSyncExternalStore } from 'react';
import {
  User,
  DriverProfile,
  Order,
  OrderStatus,
  WalletTransaction,
  AdminSettings,
  WhatsAppNotification,
  RegionZone,
  FirebaseConfig,
  DriverTopUpRequest,
  CompanyBankAccount,
  KeuanganAdminItem,
  TravelRoute,
  PriceTariff,
} from '../types';
import {
  playOrderAlertChime,
  playSuccessChime,
  playPassengerNotificationChime,
  playDriverAcceptedSound,
} from '../utils/audio';
import {
  checkIsOutsideIndonesia,
  validateIndonesianPhone,
  calculateCorridorDeviation,
  calculateOrderPricing,
} from '../utils/routePricing';
import {
  setupRealtimeListeners,
  saveOrderToFirestore,
  updateOrderInFirestore,
  saveDriverToFirestore,
  updateDriverStatusInFirestore,
  updateDriverPasswordHashInFirestore,
  updateDriverRecoveryCodeHashInFirestore,
  fetchDriverByPhoneFromFirestore,
  getCachedDriverSecrets,
  setCachedDriverSecrets,
  saveTransactionToFirestore,
  saveAdminSettingsToFirestore,
  saveTopUpRequestToFirestore,
  saveCustomerToFirestore,
  saveKeuanganAdminToFirestore,
  deleteOrderFromFirestore,
  deleteDriverFromFirestore,
  deleteCustomerFromFirestore,
  deleteKeuanganAdminFromFirestore,
  deleteTransactionFromFirestore,
  deleteTopUpRequestFromFirestore,
  clearAllTransactionsFromFirestore,
  clearAllCustomersFromFirestore,
  clearAllTopUpRequestsFromFirestore,
  ensureAdminSettingsInitialized,
  purgeDummyRecordsFromFirestore,
  testFirestoreConnection,
  fetchPaginatedOrders,
  fetchPaginatedCustomers,
  CustomerData,
} from '../services/firestoreService';

const STORAGE_KEY_AUTH = 'm3car_auth_v2';
const STORAGE_KEY_CUSTOMERS = 'm3car_customers_v2';
const STORAGE_KEY_DRIVERS = 'm3car_drivers_v2';
const STORAGE_KEY_ORDERS = 'm3car_orders_v2';
const STORAGE_KEY_TRANSACTIONS = 'm3car_transactions_v2';
const STORAGE_KEY_SETTINGS = 'm3car_settings_v2';
const STORAGE_KEY_NOTIFS = 'm3car_notifications_v2';
const STORAGE_KEY_TOPUP_REQUESTS = 'm3car_topup_requests_v2';
const STORAGE_KEY_KEUANGAN_ADMIN = 'm3car_keuangan_admin_v2';
const SESSION_KEY_ADMIN_TOKEN = 'm3car_admin_token';
const SESSION_KEY_DRIVER_TOKEN = 'm3car_driver_token';

const INITIAL_CUSTOMERS: CustomerData[] = [];

const INITIAL_KEUANGAN_ADMIN: KeuanganAdminItem[] = [];

const DEFAULT_SETTINGS: AdminSettings = {
  adminPhone: '085811594114',
  waDirekturPhone: '901102051050',
  pricePerPerson: 270000,
  pricePerKm: 3500,
  receiptTimeLimitMinutes: 30,
  companyBank: {
    bankName: 'SeaBank',
    accountNumber: '901102051050',
    accountHolder: 'Ali Husen - CV. ROYAL TRANS BERKAH GROUP',
  },
  routes: [],
  tariffs: [],
  rates: {
    jakarta: 270000,
    tangerang_depok: 275000,
    bogor_bekasi: 300000,
  },
  commissionRates: {
    longTrip: 0.12,
    shortTrip: 0.15,
  },
  tripayQrisFeeFlat: 1000,
  tripayQrisFeePercent: 0.007,
  siteContent: {
    appName: 'M3CAR',
    tagline: 'Jemput Cepat, Sampai Selamat',
    subTagline: 'Travel Antar Jemput Ujung Kulon - Jakarta',
    announcement: 'Rute Cepat Tol Serang-Panimbang (Ujung Kulon - Jakarta PP)',
    welcomeText: 'M3CAR - KHUSUS INDONESIA. Ujung Kulon - Jakarta.',
    tollRouteDesc: 'Tol Jakarta-Merak + Tol Serang-Panimbang 83,6 km',
    travelTimeEta: '6 jam 30 menit',
    bannerUrl: '',
  },
};

const INITIAL_DRIVERS: DriverProfile[] = [];

const INITIAL_ORDERS: Order[] = [];

const INITIAL_TRANSACTIONS: WalletTransaction[] = [];

const INITIAL_TOPUP_REQUESTS: DriverTopUpRequest[] = [];

// Helper to safely load JSON from localStorage
function loadLocal<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function saveLocal<T>(key: string, data: T) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error('Failed saving to localStorage', e);
  }
}

// Global dispatcher listener registry with version snapshot for useSyncExternalStore
type Listener = () => void;
const listeners = new Set<Listener>();
let storeVersion = 0;
let notifyScheduled = false;

function notify() {
  storeVersion++;
  if (!notifyScheduled) {
    notifyScheduled = true;
    queueMicrotask(() => {
      notifyScheduled = false;
      listeners.forEach((l) => {
        try {
          l();
        } catch (e) {
          console.error('Store listener error:', e);
        }
      });
    });
  }
}

function subscribeToStore(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function getStoreSnapshot() {
  return storeVersion;
}

// One-time local dummy purge so old cached dummy drivers/orders/customers never reappear
function purgeLocalDummyDataOnce() {
  if (typeof window === 'undefined') return;
  const PURGE_LOCAL_FLAG = 'm3car_purged_local_dummy_v1';
  if (localStorage.getItem(PURGE_LOCAL_FLAG) === 'true') return;

  const dummyDriverIds = new Set(['DRV-001', 'drv-2', 'drv-3']);
  const dummyDriverNames = new Set([
    'asep saepudin',
    'dedi mulyadi',
    'hendra wijaya',
    'ira wijaya',
    'rudi hartono',
    'jamaludin',
  ]);
  const dummyCustomerIds = new Set(['CUST-001', 'CUST-002', 'cust-081288990011']);
  const dummyOrderIds = new Set(['ord-malaysia-931', 'ord-101']);
  const dummyTxIds = new Set(['tx-001', 'tx-002']);
  const dummyTopUpIds = new Set(['topup-req-1', 'topup-req-2']);
  const dummyKeuanganIds = new Set(['tx-init-1', 'tx-init-2', 'tx-init-3']);

  const drivers = loadLocal<DriverProfile[]>(STORAGE_KEY_DRIVERS, []);
  saveLocal(
    STORAGE_KEY_DRIVERS,
    drivers.filter(
      (d) =>
        !dummyDriverIds.has(d.id) &&
        !dummyDriverNames.has((d.name || '').trim().toLowerCase())
    )
  );

  const customers = loadLocal<CustomerData[]>(STORAGE_KEY_CUSTOMERS, []);
  saveLocal(
    STORAGE_KEY_CUSTOMERS,
    customers.filter((c) => !dummyCustomerIds.has(c.id))
  );

  const orders = loadLocal<Order[]>(STORAGE_KEY_ORDERS, []);
  saveLocal(
    STORAGE_KEY_ORDERS,
    orders.filter((o) => !dummyOrderIds.has(o.id))
  );

  const txs = loadLocal<WalletTransaction[]>(STORAGE_KEY_TRANSACTIONS, []);
  saveLocal(
    STORAGE_KEY_TRANSACTIONS,
    txs.filter((t) => !dummyTxIds.has(t.id))
  );

  const topups = loadLocal<DriverTopUpRequest[]>(STORAGE_KEY_TOPUP_REQUESTS, []);
  saveLocal(
    STORAGE_KEY_TOPUP_REQUESTS,
    topups.filter((r) => !dummyTopUpIds.has(r.id))
  );

  const keuangan = loadLocal<KeuanganAdminItem[]>(STORAGE_KEY_KEUANGAN_ADMIN, []);
  saveLocal(
    STORAGE_KEY_KEUANGAN_ADMIN,
    keuangan.filter((k) => !dummyKeuanganIds.has(k.id))
  );

  const notifs = loadLocal<WhatsAppNotification[]>(STORAGE_KEY_NOTIFS, []);
  saveLocal(
    STORAGE_KEY_NOTIFS,
    notifs.filter((n) => n.id !== 'wa-init-1')
  );

  const authUser = loadLocal<User | DriverProfile | null>(STORAGE_KEY_AUTH, null);
  if (
    authUser &&
    (dummyDriverIds.has(authUser.id) ||
      dummyCustomerIds.has(authUser.id) ||
      dummyDriverNames.has((authUser.name || '').trim().toLowerCase()))
  ) {
    localStorage.removeItem(STORAGE_KEY_AUTH);
  }

  localStorage.setItem(PURGE_LOCAL_FLAG, 'true');
}

purgeLocalDummyDataOnce();

function getStoredAdminToken(): string {
  if (typeof window === 'undefined') return '';
  try {
    return sessionStorage.getItem(SESSION_KEY_ADMIN_TOKEN) || '';
  } catch {
    return '';
  }
}

function setStoredAdminToken(token: string | null) {
  if (typeof window === 'undefined') return;
  try {
    if (token) {
      sessionStorage.setItem(SESSION_KEY_ADMIN_TOKEN, token);
    } else {
      sessionStorage.removeItem(SESSION_KEY_ADMIN_TOKEN);
    }
  } catch {}
}

function setStoredDriverToken(token: string | null) {
  if (typeof window === 'undefined') return;
  try {
    if (token) {
      sessionStorage.setItem(SESSION_KEY_DRIVER_TOKEN, token);
    } else {
      sessionStorage.removeItem(SESSION_KEY_DRIVER_TOKEN);
    }
  } catch {}
}

function sanitizeDriverForClient(driver: DriverProfile): DriverProfile {
  const {
    password: _omitPw,
    passwordHash: _omitHash,
    recoveryCodeHash: _omitRecHash,
    recoveryCodeExpiresAt: _omitRecExp,
    ...safe
  } = driver;
  return {
    ...safe,
    hasPassword: Boolean(driver.hasPassword || driver.passwordHash),
  };
}

// In-memory master state container
let globalState = {
  currentUser: (() => {
    const cached = loadLocal<User | DriverProfile | null>(STORAGE_KEY_AUTH, null);
    if (cached?.role === 'admin') return null;
    return cached;
  })(),
  isAdminAuthenticated: false,
  isCheckingAdminSession: true,
  customers: loadLocal<CustomerData[]>(STORAGE_KEY_CUSTOMERS, INITIAL_CUSTOMERS),
  drivers: loadLocal<DriverProfile[]>(STORAGE_KEY_DRIVERS, INITIAL_DRIVERS),
  orders: loadLocal<Order[]>(STORAGE_KEY_ORDERS, INITIAL_ORDERS),
  transactions: loadLocal<WalletTransaction[]>(STORAGE_KEY_TRANSACTIONS, INITIAL_TRANSACTIONS),
  topUpRequests: loadLocal<DriverTopUpRequest[]>(STORAGE_KEY_TOPUP_REQUESTS, INITIAL_TOPUP_REQUESTS),
  keuanganAdmin: loadLocal<KeuanganAdminItem[]>(STORAGE_KEY_KEUANGAN_ADMIN, INITIAL_KEUANGAN_ADMIN),
  settings: (() => {
    const loaded = loadLocal<AdminSettings>(STORAGE_KEY_SETTINGS, DEFAULT_SETTINGS);
    if ('adminPasswordHash' in loaded) {
      delete loaded.adminPasswordHash;
    }
    if (!loaded.companyBank || !loaded.companyBank.accountNumber) {
      loaded.companyBank = {
        bankName: 'SeaBank',
        accountNumber: '901102051050',
        accountHolder: 'Ali Husen - CV. ROYAL TRANS BERKAH GROUP',
      };
    }
    if (!loaded.waDirekturPhone) {
      loaded.waDirekturPhone = '901102051050';
    }
    if (!loaded.receiptTimeLimitMinutes) {
      loaded.receiptTimeLimitMinutes = 30;
    }
    if (!Array.isArray(loaded.routes)) {
      loaded.routes = [];
    }
    if (!Array.isArray(loaded.tariffs)) {
      loaded.tariffs = [];
    }
    saveLocal(STORAGE_KEY_SETTINGS, loaded);
    return loaded;
  })(),
  notifications: loadLocal<WhatsAppNotification[]>(STORAGE_KEY_NOTIFS, []),
  isFirebaseConnected: true,
};

// Auto sync across browser tabs via storage event
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (event.key?.startsWith('m3car_')) {
      globalState = {
        ...globalState,
        currentUser: loadLocal(STORAGE_KEY_AUTH, globalState.currentUser),
        customers: loadLocal(STORAGE_KEY_CUSTOMERS, globalState.customers),
        drivers: loadLocal(STORAGE_KEY_DRIVERS, globalState.drivers),
        orders: loadLocal(STORAGE_KEY_ORDERS, globalState.orders),
        transactions: loadLocal(STORAGE_KEY_TRANSACTIONS, globalState.transactions),
        topUpRequests: loadLocal(STORAGE_KEY_TOPUP_REQUESTS, globalState.topUpRequests),
        keuanganAdmin: loadLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin),
        settings: loadLocal(STORAGE_KEY_SETTINGS, globalState.settings),
        notifications: loadLocal(STORAGE_KEY_NOTIFS, globalState.notifications),
      };
      notify();
    }
  });
}

// Automatically connect to Firebase Firestore
if (typeof window !== 'undefined') {
  testFirestoreConnection();

  setupRealtimeListeners({
    onActiveOrdersChange: (newOrders) => {
      const prevCount = globalState.orders.filter((o) => o.status === 'MENCARI_DRIVER').length;
      const newCount = newOrders.filter((o) => o.status === 'MENCARI_DRIVER').length;
      if (newCount > prevCount) {
        playOrderAlertChime();
      }
      const sortedOrders = [...newOrders];
      sortedOrders.sort((a, b) => ((b.createdAt || '') > (a.createdAt || '') ? 1 : -1));

      globalState.orders = sortedOrders;
      saveLocal(STORAGE_KEY_ORDERS, sortedOrders);
      notify();
    },
    onDriversChange: (newDrivers) => {
      const sanitizedList = (newDrivers || []).map(sanitizeDriverForClient);
      globalState.drivers = sanitizedList;
      saveLocal(STORAGE_KEY_DRIVERS, sanitizedList);
      // Sync current session driver if matched
      if (globalState.currentUser && globalState.currentUser.role === 'driver') {
        const match = sanitizedList.find((d) => d.id === globalState.currentUser?.id);
        if (match) {
          globalState.currentUser = match;
          saveLocal(STORAGE_KEY_AUTH, match);
        }
      }
      notify();
    },
    onCustomersChange: (newCustomers) => {
      globalState.customers = newCustomers || [];
      saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);
      notify();
    },
    onSettingsChange: (newSettings) => {
      globalState.settings = { ...globalState.settings, ...newSettings };
      saveLocal(STORAGE_KEY_SETTINGS, globalState.settings);
      notify();
    },
    onTransactionsChange: (newTx) => {
      globalState.transactions = newTx || [];
      saveLocal(STORAGE_KEY_TRANSACTIONS, globalState.transactions);
      notify();
    },
    onTopUpRequestsChange: (newReqs) => {
      globalState.topUpRequests = newReqs || [];
      saveLocal(STORAGE_KEY_TOPUP_REQUESTS, globalState.topUpRequests);
      notify();
    },
    onKeuanganAdminChange: (items) => {
      globalState.keuanganAdmin = items || [];
      saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin);
      notify();
    },
    onConnected: (connected) => {
      globalState.isFirebaseConnected = connected;
      notify();
    },
  });

  // Clean up any legacy dummy data in Firestore and ensure Admin settings exist
  purgeDummyRecordsFromFirestore();
  ensureAdminSettingsInitialized(globalState.settings);
}

function generateNextCustomerId(existingCustomers: CustomerData[]): string {
  let maxNum = 0;
  existingCustomers.forEach((c) => {
    const match = (c.id || '').match(/CUST-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  });
  if (maxNum === 0) {
    maxNum = existingCustomers.length;
  }
  return `CUST-${String(maxNum + 1).padStart(3, '0')}`;
}

function generateNextDriverId(existingDrivers: DriverProfile[]): string {
  let maxNum = 0;
  existingDrivers.forEach((d) => {
    const match = (d.id || '').match(/DRV-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  });
  if (maxNum === 0) {
    maxNum = existingDrivers.length;
  }
  return `DRV-${String(maxNum + 1).padStart(3, '0')}`;
}

export function normalizePhone(raw: string): string {
  if (!raw) return '';
  let cleaned = raw.replace(/\D/g, '');
  if (cleaned.startsWith('62')) {
    cleaned = '0' + cleaned.slice(2);
  } else if (cleaned.startsWith('8')) {
    cleaned = '0' + cleaned;
  }
  return cleaned;
}

export function normalizeName(raw: string): string {
  return (raw || '').trim().toLowerCase();
}

export function useM3CarStore() {
  useSyncExternalStore(subscribeToStore, getStoreSnapshot, () => 0);

  // WhatsApp simulation helper
  const sendWhatsAppNotification = (
    phone: string,
    name: string,
    role: 'driver' | 'customer' | 'admin',
    title: string,
    message: string,
    type: WhatsAppNotification['type']
  ) => {
    const newNotif: WhatsAppNotification = {
      id: `wa-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      recipientPhone: phone,
      recipientName: name,
      recipientRole: role,
      title,
      message,
      timestamp: new Date().toLocaleString('id-ID'),
      type,
    };
    const updated = [newNotif, ...globalState.notifications].slice(0, 50);
    globalState.notifications = updated;
    saveLocal(STORAGE_KEY_NOTIFS, updated);
    notify();
  };

  // Server-backed Admin Authentication Actions
  const verifyAdminSessionWithServer = async (): Promise<boolean> => {
    globalState.isCheckingAdminSession = true;
    notify();
    try {
      const token = getStoredAdminToken();
      const headers: Record<string, string> = {};
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
      const res = await fetch('/api/admin/session', {
        method: 'GET',
        credentials: 'include',
        headers,
      });
      if (res.ok) {
        const data = await res.json();
        if (data?.ok && data?.authenticated) {
          const adminUser: User = {
            id: 'admin-root',
            name: data.user?.name || 'Admin Pusat M3CAR',
            phone: globalState.settings.adminPhone || '085811594114',
            role: 'admin',
          };
          globalState.currentUser = adminUser;
          globalState.isAdminAuthenticated = true;
          globalState.isCheckingAdminSession = false;
          notify();
          return true;
        }
      }
    } catch (err) {
      console.warn('Admin session check failed:', err);
    }
    setStoredAdminToken(null);
    if (globalState.currentUser?.role === 'admin') {
      globalState.currentUser = null;
      saveLocal(STORAGE_KEY_AUTH, null);
    }
    globalState.isAdminAuthenticated = false;
    globalState.isCheckingAdminSession = false;
    notify();
    return false;
  };

  const loginAdminWithServer = async (code: string): Promise<{ success: boolean; message?: string }> => {
    const trimmedCode = (code || '').trim();
    if (!trimmedCode) {
      return { success: false, message: 'Masukkan Kode Admin.' };
    }
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: trimmedCode }),
      });
      const contentType = (res.headers.get('content-type') || '').toLowerCase();
      if (!contentType.includes('application/json')) {
        return {
          success: false,
          message: 'Server API login tidak mengembalikan JSON. Periksa konfigurasi Netlify Functions & redirect /api/admin/*.',
        };
      }
      const data = await res.json().catch(() => null);
      if (!data || typeof data !== 'object') {
        return {
          success: false,
          message: 'Respons server login tidak valid.',
        };
      }
      if (res.ok && data.ok) {
        if (data.token) {
          setStoredAdminToken(data.token);
        }
        const adminUser: User = {
          id: 'admin-root',
          name: data.user?.name || 'Admin Pusat M3CAR',
          phone: globalState.settings.adminPhone || '085811594114',
          role: 'admin',
        };
        globalState.currentUser = adminUser;
        globalState.isAdminAuthenticated = true;
        globalState.isCheckingAdminSession = false;
        notify();
        return { success: true };
      }
      return { success: false, message: data.message || 'Kode Salah' };
    } catch {
      return { success: false, message: 'Gagal terhubung ke server verifikasi admin.' };
    }
  };

  const logoutAdminWithServer = async () => {
    try {
      const token = getStoredAdminToken();
      const headers: Record<string, string> = {};
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
      await fetch('/api/admin/logout', {
        method: 'POST',
        credentials: 'include',
        headers,
      });
    } catch {
      // ignore network errors on logout cleanup
    }
    setStoredAdminToken(null);
    globalState.isAdminAuthenticated = false;
    globalState.currentUser = null;
    saveLocal(STORAGE_KEY_AUTH, null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('m3car_admin_session_persistent');
      localStorage.removeItem(STORAGE_KEY_AUTH);
    }
    notify();
  };

  const changeAdminCodeWithServer = async (
    currentCode: string,
    newCode: string
  ): Promise<{ success: boolean; message: string }> => {
    try {
      const token = getStoredAdminToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
      }
      const res = await fetch('/api/admin/change-code', {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({ currentCode, newCode }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data?.ok) {
        return { success: true, message: data.message || 'Kode Admin berhasil diperbarui di server.' };
      }
      return { success: false, message: data?.message || 'Gagal memperbarui Kode Admin.' };
    } catch {
      return { success: false, message: 'Gagal terhubung ke server.' };
    }
  };

  // Auth actions
  const login = (phone: string, _password?: string, role?: 'customer' | 'driver' | 'admin') => {
    if (role === 'admin') {
      return { success: false, message: 'Gunakan verifikasi server Panel Admin.' };
    }

    // 2. DRIVER LOGIN WAJIB MENGGUNAKAN KATA SANDI PRIBADI (via loginDriverWithPassword)
    if (role === 'driver') {
      return {
        success: false,
        message: 'Masuk Driver wajib menggunakan Nomor HP dan Kata Sandi pribadi.',
      };
    }

    // 3. CUSTOMER LOGIN / AUTO-REGISTER (Tanpa Password, Cukup Nomor HP)
    if (role === 'customer' || !role) {
      const phoneCheck = validateIndonesianPhone(phone);
      if (!phoneCheck.isValid) {
        return {
          success: false,
          message: phoneCheck.errorMessage || 'Hanya Nomor HP Indonesia (+62) yang bisa daftar. Nomor asing ditolak.',
        };
      }
      const cleanPhone = phoneCheck.cleanedPhone;

      // Cek apakah nomor sudah ada
      const existing = globalState.customers.find(
        (c) => (c.no_hp && c.no_hp.replace(/\D/g, '') === cleanPhone.replace(/\D/g, '')) ||
               (c.phone && c.phone.replace(/\D/g, '') === cleanPhone.replace(/\D/g, ''))
      );

      if (existing) {
        const custUser: User = {
          id: existing.id,
          name: existing.nama || existing.name || `Pelanggan ${cleanPhone.slice(-4)}`,
          phone: cleanPhone,
          role: 'customer',
        };
        globalState.currentUser = custUser;
        saveLocal(STORAGE_KEY_AUTH, custUser);
        notify();
        return {
          success: true,
          user: custUser,
          alreadyRegistered: true,
          message: 'Nomor ini sudah terdaftar, langsung masuk.',
        };
      }

      // Buat baru jika belum ada
      const nextId = generateNextCustomerId(globalState.customers);
      const now = new Date().toLocaleString('id-ID');
      const custUser: User = {
        id: nextId,
        name: `Customer ${cleanPhone.slice(-4)}`,
        phone: cleanPhone,
        role: 'customer',
      };
      globalState.currentUser = custUser;
      saveLocal(STORAGE_KEY_AUTH, custUser);

      const customerDoc: CustomerData = {
        id: nextId,
        nama: custUser.name,
        no_hp: cleanPhone,
        alamat: 'Ujung Kulon / Jakarta',
        tanggal_daftar: now,
        name: custUser.name,
        phone: cleanPhone,
        role: 'customer',
        createdAt: now,
      };
      saveCustomerToFirestore(customerDoc);

      const updatedCusts = [customerDoc, ...globalState.customers];
      globalState.customers = updatedCusts;
      saveLocal(STORAGE_KEY_CUSTOMERS, updatedCusts);

      notify();
      return { success: true, user: custUser, message: 'Pendaftaran berhasil!' };
    }

    return { success: false, message: 'Nomor HP tidak sesuai.' };
  };

  // Dedicated Customer Registration (Tanpa Password, ID: CUST-001, CUST-002, dst)
  const registerCustomer = (data: { name: string; phone: string; address?: string }) => {
    const phoneCheck = validateIndonesianPhone(data.phone);
    if (!phoneCheck.isValid) {
      return {
        success: false,
        message: phoneCheck.errorMessage || 'Hanya Nomor HP Indonesia (+62) yang bisa daftar. Nomor asing ditolak.',
      };
    }

    const cleanPhone = phoneCheck.cleanedPhone;
    const cleanName = data.name.trim() || 'Penumpang M3Car';

    // Cek apakah nomor sudah ada
    const existing = globalState.customers.find(
      (c) => (c.no_hp && c.no_hp.replace(/\D/g, '') === cleanPhone.replace(/\D/g, '')) ||
             (c.phone && c.phone.replace(/\D/g, '') === cleanPhone.replace(/\D/g, ''))
    );

    if (existing) {
      const custUser: User = {
        id: existing.id,
        name: existing.nama || existing.name || cleanName,
        phone: cleanPhone,
        role: 'customer',
      };
      globalState.currentUser = custUser;
      saveLocal(STORAGE_KEY_AUTH, custUser);
      notify();
      return {
        success: true,
        alreadyRegistered: true,
        message: 'Nomor ini sudah terdaftar, langsung masuk.',
        customer: existing,
        user: custUser,
      };
    }

    const nextId = generateNextCustomerId(globalState.customers);
    const now = new Date().toLocaleString('id-ID');
    const custDoc: CustomerData = {
      id: nextId,
      nama: cleanName,
      no_hp: cleanPhone,
      alamat: data.address || 'Ujung Kulon / Jakarta',
      tanggal_daftar: now,
      name: cleanName,
      phone: cleanPhone,
      role: 'customer',
      createdAt: now,
    };

    saveCustomerToFirestore(custDoc);

    const updatedCusts = [custDoc, ...globalState.customers];
    globalState.customers = updatedCusts;
    saveLocal(STORAGE_KEY_CUSTOMERS, updatedCusts);

    const custUser: User = {
      id: nextId,
      name: cleanName,
      phone: cleanPhone,
      role: 'customer',
    };
    globalState.currentUser = custUser;
    saveLocal(STORAGE_KEY_AUTH, custUser);

    try {
      localStorage.setItem('m3car_penumpang_profile', JSON.stringify({
        name: cleanName,
        phone: cleanPhone,
      }));
    } catch {}

    notify();
    return {
      success: true,
      alreadyRegistered: false,
      message: 'Pendaftaran berhasil!',
      customer: custDoc,
      user: custUser,
    };
  };

  const logout = () => {
    const wasDriver = globalState.currentUser?.role === 'driver';
    globalState.currentUser = null;
    saveLocal(STORAGE_KEY_AUTH, null);
    setStoredDriverToken(null);
    if (wasDriver && typeof window !== 'undefined') {
      fetch('/api/driver/logout', { method: 'POST', credentials: 'include' }).catch(() => {});
    }
    if (typeof window !== 'undefined') {
      localStorage.removeItem('m3car_admin_session_persistent');
      localStorage.removeItem('m3car_penumpang_profile');
      localStorage.removeItem(STORAGE_KEY_AUTH);
    }
    notify();
  };

  // 1 HALAMAN MASUK (Auto-detect Role untuk Penumpang; Driver wajib pakai kata sandi di Portal Driver)
  const loginUnified = (name: string, phone: string) => {
    const trimmedName = (name || '').trim();
    const cleanPhone = normalizePhone(phone);

    if (!trimmedName || !cleanPhone) {
      return { success: false, message: 'Silakan isi Nama Lengkap dan Nomor WhatsApp Anda.' };
    }

    if (cleanPhone.length < 10 || cleanPhone.length > 14 || !cleanPhone.startsWith('08')) {
      return { success: false, message: 'Nomor HP tidak valid. Masukkan nomor HP Indonesia yang aktif (08...).' };
    }

    // 2. JIKA NOMOR TERDAFTAR SEBAGAI DRIVER, TOLAK LOGIN TANPA SANDI
    const driverByPhone = globalState.drivers.find(
      (d) => d && !d.isDeleted && d.phone && normalizePhone(d.phone) === cleanPhone
    );

    if (driverByPhone) {
      return {
        success: false,
        message: 'Nomor ini terdaftar sebagai Mitra Driver. Silakan masuk melalui Portal Driver dengan kata sandi pribadi Anda.',
      };
    }

    // 3. CEK CUSTOMER TERDAFTAR BERDASARKAN NOMOR HP (Langsung masuk, tanpa blokir)
    const customerByPhone = globalState.customers.find((c) => {
      const p = c.no_hp || c.phone || '';
      return p && normalizePhone(p) === cleanPhone;
    });

    if (customerByPhone) {
      const existingName = customerByPhone.nama || customerByPhone.name || trimmedName;
      const custUser: User = {
        id: customerByPhone.id,
        name: existingName,
        phone: cleanPhone,
        role: 'customer',
        avatarUrl: customerByPhone.foto_profil || customerByPhone.avatarUrl,
      };
      globalState.currentUser = custUser;
      saveLocal(STORAGE_KEY_AUTH, custUser);
      try {
        localStorage.setItem('m3car_penumpang_profile', JSON.stringify({
          name: existingName,
          phone: cleanPhone,
          avatarUrl: custUser.avatarUrl,
        }));
      } catch {}
      notify();
      return {
        success: true,
        role: 'customer' as const,
        user: custUser,
        message: 'Nomor ini sudah terdaftar, langsung masuk.',
      };
    }

    // 4. Belum pernah terdaftar: Ijinkan SEMUA ORANG bisa daftar tanpa batas (CUST-001, CUST-002, dst)
    const nextId = generateNextCustomerId(globalState.customers);
    const now = new Date().toLocaleString('id-ID');
    const custUser: User = {
      id: nextId,
      name: trimmedName,
      phone: cleanPhone,
      role: 'customer',
    };
    const newCustomerDoc: CustomerData = {
      id: nextId,
      nama: trimmedName,
      no_hp: cleanPhone,
      name: trimmedName,
      phone: cleanPhone,
      alamat: 'Ujung Kulon / Jakarta',
      tanggal_daftar: now,
      role: 'customer',
      createdAt: now,
    };

    saveCustomerToFirestore(newCustomerDoc);
    globalState.customers = [newCustomerDoc, ...globalState.customers];
    saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);

    globalState.currentUser = custUser;
    saveLocal(STORAGE_KEY_AUTH, custUser);

    try {
      localStorage.setItem('m3car_penumpang_profile', JSON.stringify({
        name: trimmedName,
        phone: cleanPhone,
      }));
    } catch {}

    notify();
    return {
      success: true,
      role: 'customer' as const,
      user: custUser,
      message: `Pendaftaran berhasil! Selamat datang, ${trimmedName}.`,
    };
  };

  const switchRole = (targetRole: 'customer' | 'driver' | 'admin') => {
    if (targetRole === 'admin') {
      return;
    } else if (targetRole === 'driver') {
      if (globalState.currentUser && globalState.currentUser.role === 'driver') {
        return;
      }
      // Driver wajib login memakai Nomor HP & Kata Sandi Pribadi (jangan auto-login driver)
      globalState.currentUser = null;
      saveLocal(STORAGE_KEY_AUTH, null);
      notify();
    } else {
      let savedPhone = '';
      try {
        const raw = localStorage.getItem('m3car_penumpang_profile');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && parsed.phone) savedPhone = parsed.phone;
        }
      } catch {}

      if (savedPhone) {
        login(savedPhone, undefined, 'customer');
      } else if (globalState.currentUser?.role === 'customer' && globalState.currentUser?.phone) {
        // keep current customer
      } else {
        globalState.currentUser = null;
        saveLocal(STORAGE_KEY_AUTH, null);
        notify();
      }
    }
  };

  // Dedicated Driver Registration (KTP & SIM A wajib, TANPA SELFIE, Kata Sandi Pribadi di-hash di Server)
  const registerDriver = async (data: {
    name: string;
    phone: string;
    plateNumber: string;
    carModel: string;
    ktpPhotoUrl: string;
    simPhotoUrl: string;
    password: string;
    confirmPassword: string;
  }): Promise<{
    success: boolean;
    message?: string;
    code?: string;
    pendingDriverId?: string;
    needsFirstPassword?: boolean;
    driver?: DriverProfile;
  }> => {
    const phoneCheck = validateIndonesianPhone(data.phone);
    if (!phoneCheck.isValid) {
      return {
        success: false,
        message: phoneCheck.errorMessage || 'Hanya Nomor HP Indonesia (+62) yang bisa daftar.',
      };
    }

    if (!data.name.trim()) {
      return { success: false, message: 'Nama Lengkap wajib diisi.' };
    }
    if (!data.plateNumber.trim()) {
      return { success: false, message: 'No Polisi wajib diisi.' };
    }
    if (!data.carModel.trim()) {
      return { success: false, message: 'Merk Mobil wajib diisi.' };
    }
    if (!data.ktpPhotoUrl) {
      return { success: false, message: 'Foto KTP wajib diupload.' };
    }
    if (!data.simPhotoUrl) {
      return { success: false, message: 'Foto SIM A wajib diupload.' };
    }
    if (!data.password || data.password.length < 6) {
      return { success: false, message: 'Kata sandi pribadi minimal 6 karakter.' };
    }
    if (data.password !== data.confirmPassword) {
      return { success: false, message: 'Konfirmasi kata sandi tidak cocok.' };
    }

    const cleanPhone = normalizePhone(phoneCheck.cleanedPhone);
    const cleanName = data.name.trim();
    const cleanPlate = data.plateNumber.trim().toUpperCase();
    const cleanCar = data.carModel.trim();

    // ATURAN 4: Setiap nomor HP hanya boleh memiliki satu akun (cek lokal + live Firestore)
    const localExisting = globalState.drivers.find(
      (d) => !d.isDeleted && d.phone && normalizePhone(d.phone) === cleanPhone
    );
    const firestoreMatch = await fetchDriverByPhoneFromFirestore(cleanPhone);
    const existing = localExisting || (firestoreMatch && !firestoreMatch.driver.isDeleted ? firestoreMatch.driver : null);

    if (existing) {
      const hasPw = Boolean(existing.hasPassword || firestoreMatch?.passwordHash || getCachedDriverSecrets(existing.id).passwordHash);
      if (!hasPw) {
        return {
          success: false,
          code: 'LEGACY_NO_PASSWORD',
          needsFirstPassword: true,
          message:
            'Nomor HP ini sudah terdaftar sebagai akun Driver lama dan belum memiliki kata sandi. Gunakan menu "Buat Kata Sandi Pertama Kali" tanpa perlu daftar ulang.',
        };
      }
      return {
        success: false,
        code: 'PHONE_ALREADY_REGISTERED',
        message:
          'Nomor HP ini sudah terdaftar sebagai akun Driver. Setiap nomor HP hanya boleh memiliki satu akun.',
      };
    }

    // ATURAN 6: Hash kata sandi di server (JANGAN simpan kata sandi asli)
    let hashedData: { ok?: boolean; passwordHash?: string; passwordUpdatedAt?: string; message?: string } | null = null;
    try {
      const res = await fetch('/api/driver/hash-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          password: data.password,
          confirmPassword: data.confirmPassword,
        }),
      });
      hashedData = await res.json().catch(() => null);
      if (!res.ok || !hashedData?.ok || !hashedData?.passwordHash) {
        return {
          success: false,
          message: hashedData?.message || 'Gagal mengamankan kata sandi di server.',
        };
      }
    } catch {
      return {
        success: false,
        message: 'Gagal terhubung ke server keamanan untuk mengenkripsi kata sandi.',
      };
    }

    const nextId = generateNextDriverId(globalState.drivers);
    const now = new Date().toLocaleString('id-ID');

    const driverForDb: DriverProfile = {
      id: nextId,
      name: cleanName,
      phone: cleanPhone,
      role: 'driver',
      status: 'MENUNGGU',
      rawStatus: 'waiting_approval',
      carModel: cleanCar,
      car: cleanCar,
      plateNumber: cleanPlate,
      plate: cleanPlate,
      isOnline: false,
      balance: 100000,
      saldo: 100000,
      rating: 5.0,
      totalTrips: 0,
      ktpPhotoUrl: data.ktpPhotoUrl,
      ktpUrl: data.ktpPhotoUrl,
      simPhotoUrl: data.simPhotoUrl,
      simUrl: data.simPhotoUrl,
      registeredAt: now,
      hasPassword: true,
      passwordHash: hashedData.passwordHash,
      passwordUpdatedAt: hashedData.passwordUpdatedAt || new Date().toISOString(),
    };

    setCachedDriverSecrets(nextId, { passwordHash: hashedData.passwordHash });
    const safeDriver = sanitizeDriverForClient(driverForDb);

    const updated = [safeDriver, ...globalState.drivers];
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    // Sync to Firebase Firestore collection 'drivers' (status: waiting_approval, hanya passwordHash — tanpa kata sandi asli)
    await saveDriverToFirestore(driverForDb);

    // Send WhatsApp notification
    sendWhatsAppNotification(
      safeDriver.phone,
      safeDriver.name,
      'driver',
      'Pendaftaran Driver Diterima (Menunggu Persetujuan Admin)',
      `Halo ${safeDriver.name}, pendaftaran Mitra Driver M3CAR (${cleanPlate} - ${cleanCar}) telah diterima dengan status MENUNGGU PERSETUJUAN ADMIN. Setelah Admin menyetujui, silakan masuk dengan Nomor HP & kata sandi pribadi Anda.`,
      'acc'
    );

    notify();
    return {
      success: true,
      pendingDriverId: nextId,
      driver: safeDriver,
      message:
        'Pendaftaran berhasil! Akun berstatus MENUNGGU PERSETUJUAN ADMIN. Setelah disetujui Admin, masuk dengan Nomor HP dan kata sandi Anda.',
    };
  };

  // Driver Login dengan Nomor HP & Kata Sandi Pribadi (Verifikasi Server + Cek Status Persetujuan Admin)
  const loginDriverWithPassword = async (
    phoneInput: string,
    passwordInput: string
  ): Promise<{
    success: boolean;
    message?: string;
    needsFirstPassword?: boolean;
    pendingApproval?: boolean;
    blocked?: boolean;
    driverId?: string;
    driverPhone?: string;
    driverName?: string;
    user?: DriverProfile;
  }> => {
    const cleanPhone = normalizePhone(phoneInput);
    if (!cleanPhone || cleanPhone.length < 9) {
      return { success: false, message: 'Masukkan Nomor HP Indonesia yang valid.' };
    }
    if (!passwordInput) {
      return { success: false, message: 'Kata sandi wajib diisi.' };
    }

    const firestoreMatch = await fetchDriverByPhoneFromFirestore(cleanPhone);
    const localMatch = globalState.drivers.find(
      (d) => d?.phone && normalizePhone(d.phone) === cleanPhone
    );

    const driver = firestoreMatch?.driver || localMatch;
    if (!driver) {
      return {
        success: false,
        message: 'Nomor HP driver belum terdaftar. Silakan daftar sebagai Mitra Driver terlebih dahulu.',
      };
    }

    if (driver.isDeleted) {
      return {
        success: false,
        message: 'Akun driver ini telah dihapus oleh Admin.',
      };
    }

    // Pastikan state lokal tersinkron dengan dokumen terbaru dari Firestore
    if (firestoreMatch?.driver) {
      const sanitized = sanitizeDriverForClient(firestoreMatch.driver);
      const existsInLocal = globalState.drivers.some((d) => d.id === sanitized.id);
      globalState.drivers = existsInLocal
        ? globalState.drivers.map((d) => (d.id === sanitized.id ? sanitized : d))
        : [sanitized, ...globalState.drivers];
      saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
    }

    const cachedSecrets = getCachedDriverSecrets(driver.id);
    const passwordHash = firestoreMatch?.passwordHash || cachedSecrets.passwordHash;

    // ATURAN 10: Driver lama belum punya kata sandi -> arahkan ke Buat Kata Sandi Pertama Kali
    if (!passwordHash && !driver.hasPassword) {
      return {
        success: false,
        needsFirstPassword: true,
        driverId: driver.id,
        driverPhone: driver.phone,
        driverName: driver.name,
        message:
          'Akun driver lama Anda belum memiliki kata sandi. Silakan buat kata sandi pertama kali tanpa mengulang pendaftaran atau unggah ulang KTP/SIM.',
      };
    }

    if (!passwordHash) {
      return {
        success: false,
        message:
          'Data verifikasi kata sandi belum termuat dari server database. Pastikan koneksi internet aktif lalu coba lagi.',
      };
    }

    try {
      const res = await fetch('/api/driver/verify-password', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          password: passwordInput,
          passwordHash,
          driverId: driver.id,
          phone: cleanPhone,
          name: driver.name,
          status: driver.status,
        }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok || !data?.verified) {
        return {
          success: false,
          pendingApproval: Boolean(data?.pendingApproval),
          blocked: Boolean(data?.blocked),
          driverId: driver.id,
          driverPhone: driver.phone,
          driverName: driver.name,
          message: data?.message || 'Nomor HP atau kata sandi salah.',
        };
      }

      if (data.token) {
        setStoredDriverToken(data.token);
      }

      const safeDriver = sanitizeDriverForClient(driver);
      globalState.currentUser = safeDriver;
      saveLocal(STORAGE_KEY_AUTH, safeDriver);
      notify();
      return {
        success: true,
        user: safeDriver,
      };
    } catch {
      return {
        success: false,
        message: 'Gagal terhubung ke server verifikasi login driver.',
      };
    }
  };

  // ATURAN 10: Fasilitas Driver Lama membuat kata sandi pertama kali tanpa daftar ulang / unggah dokumen
  const setupFirstTimeDriverPassword = async (data: {
    phone: string;
    plateNumber: string;
    fullName?: string;
    password: string;
    confirmPassword: string;
  }): Promise<{ success: boolean; message: string; status?: DriverProfile['status'] }> => {
    const cleanPhone = normalizePhone(data.phone);
    if (!cleanPhone) {
      return { success: false, message: 'Masukkan Nomor HP terdaftar.' };
    }
    if (!data.plateNumber.trim()) {
      return { success: false, message: 'Masukkan Nomor Polisi (Plat Kendaraan) yang terdaftar untuk verifikasi.' };
    }

    const firestoreMatch = await fetchDriverByPhoneFromFirestore(cleanPhone);
    const localMatch = globalState.drivers.find(
      (d) => !d.isDeleted && d.phone && normalizePhone(d.phone) === cleanPhone
    );
    const driver = firestoreMatch?.driver || localMatch;

    if (!driver || driver.isDeleted) {
      return {
        success: false,
        message: 'Nomor HP driver lama tidak ditemukan. Pastikan nomor HP sesuai data pendaftaran.',
      };
    }

    const cachedSecrets = getCachedDriverSecrets(driver.id);
    const hasExistingPassword = Boolean(
      firestoreMatch?.passwordHash || cachedSecrets.passwordHash || driver.hasPassword
    );

    try {
      const res = await fetch('/api/driver/first-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: cleanPhone,
          plateNumber: data.plateNumber,
          fullName: data.fullName || '',
          storedPhone: driver.phone,
          storedPlate: driver.plateNumber || driver.plate || '',
          storedName: driver.name || '',
          hasExistingPassword,
          password: data.password,
          confirmPassword: data.confirmPassword,
        }),
      });
      const resp = await res.json().catch(() => null);
      if (!res.ok || !resp?.ok || !resp?.passwordHash) {
        return {
          success: false,
          message: resp?.message || 'Gagal membuat kata sandi pertama kali.',
        };
      }

      const passwordUpdatedAt = resp.passwordUpdatedAt || new Date().toISOString();
      await updateDriverPasswordHashInFirestore(driver.id, resp.passwordHash, passwordUpdatedAt, false);

      const updatedDriver: DriverProfile = sanitizeDriverForClient({
        ...driver,
        hasPassword: true,
        passwordUpdatedAt,
      });
      globalState.drivers = globalState.drivers.map((d) =>
        d.id === driver.id ? updatedDriver : d
      );
      saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
      notify();

      return {
        success: true,
        status: driver.status,
        message:
          driver.status === 'AKTIF'
            ? 'Kata sandi pribadi berhasil dibuat tanpa perlu daftar ulang! Silakan masuk dengan Nomor HP & kata sandi Anda.'
            : 'Kata sandi pribadi berhasil dibuat! Status akun Anda saat ini menunggu persetujuan Admin.',
      };
    } catch {
      return {
        success: false,
        message: 'Gagal terhubung ke server keamanan untuk menyimpan kata sandi.',
      };
    }
  };

  // ATURAN 9: Lupa Kata Sandi & Pemulihan Akun yang Aman
  const recoverDriverPassword = async (data: {
    phone: string;
    plateNumber?: string;
    fullName?: string;
    recoveryCode?: string;
    newPassword: string;
    confirmPassword: string;
  }): Promise<{ success: boolean; message: string }> => {
    const cleanPhone = normalizePhone(data.phone);
    if (!cleanPhone) {
      return { success: false, message: 'Nomor HP terdaftar wajib diisi.' };
    }

    const firestoreMatch = await fetchDriverByPhoneFromFirestore(cleanPhone);
    const localMatch = globalState.drivers.find(
      (d) => !d.isDeleted && d.phone && normalizePhone(d.phone) === cleanPhone
    );
    const driver = firestoreMatch?.driver || localMatch;

    if (!driver || driver.isDeleted) {
      return {
        success: false,
        message: 'Nomor HP driver tidak ditemukan.',
      };
    }

    const cachedSecrets = getCachedDriverSecrets(driver.id);
    const recoveryCodeHash =
      firestoreMatch?.recoveryCodeHash || cachedSecrets.recoveryCodeHash || '';
    const recoveryCodeExpiresAt =
      firestoreMatch?.recoveryCodeExpiresAt || cachedSecrets.recoveryCodeExpiresAt || '';

    try {
      const res = await fetch('/api/driver/recover-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: cleanPhone,
          plateNumber: data.plateNumber || '',
          fullName: data.fullName || '',
          recoveryCode: data.recoveryCode || '',
          storedPhone: driver.phone,
          storedPlate: driver.plateNumber || driver.plate || '',
          storedName: driver.name || '',
          storedRecoveryCodeHash: recoveryCodeHash,
          storedRecoveryExpiresAt: recoveryCodeExpiresAt,
          newPassword: data.newPassword,
          confirmPassword: data.confirmPassword,
        }),
      });
      const resp = await res.json().catch(() => null);
      if (!res.ok || !resp?.ok || !resp?.passwordHash) {
        return {
          success: false,
          message: resp?.message || 'Pemulihan kata sandi gagal.',
        };
      }

      const passwordUpdatedAt = resp.passwordUpdatedAt || new Date().toISOString();
      await updateDriverPasswordHashInFirestore(driver.id, resp.passwordHash, passwordUpdatedAt, true);

      const updatedDriver: DriverProfile = sanitizeDriverForClient({
        ...driver,
        hasPassword: true,
        passwordUpdatedAt,
      });
      globalState.drivers = globalState.drivers.map((d) =>
        d.id === driver.id ? updatedDriver : d
      );
      saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
      notify();

      return {
        success: true,
        message:
          'Pemulihan akun berhasil! Kata sandi baru Anda sudah aktif. Silakan masuk dengan kata sandi baru.',
      };
    } catch {
      return {
        success: false,
        message: 'Gagal terhubung ke server pemulihan kata sandi.',
      };
    }
  };

  // Admin helper: generate one-time 6-digit recovery code (stored ONLY as scrypt hash in Firestore)
  const generateDriverRecoveryCode = async (
    driverId: string
  ): Promise<{ success: boolean; recoveryCode?: string; expiresAt?: string; message?: string }> => {
    const token = getStoredAdminToken();
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers.Authorization = `Bearer ${token}`;

    try {
      const res = await fetch('/api/driver/generate-recovery-code', {
        method: 'POST',
        credentials: 'include',
        headers,
        body: JSON.stringify({ driverId }),
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || !data?.ok || !data?.recoveryCode) {
        return {
          success: false,
          message: data?.message || 'Gagal membuat kode pemulihan di server.',
        };
      }

      await updateDriverRecoveryCodeHashInFirestore(
        driverId,
        data.recoveryCodeHash,
        data.recoveryCodeExpiresAt
      );

      return {
        success: true,
        recoveryCode: data.recoveryCode,
        expiresAt: data.recoveryCodeExpiresAt,
      };
    } catch {
      return {
        success: false,
        message: 'Gagal terhubung ke server Admin untuk membuat kode pemulihan.',
      };
    }
  };

  // Resubmit KTP & SIM A documents if rejected
  const resubmitDriverDocuments = (driverId: string, ktpUrl: string, simUrl: string) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return;

    const updatedDriver: DriverProfile = {
      ...driver,
      ktpPhotoUrl: ktpUrl,
      ktpUrl,
      simPhotoUrl: simUrl,
      simUrl,
      status: 'MENUNGGU',
      rawStatus: 'waiting_approval',
      rejectionReason: undefined,
      isOnline: false,
    };
    const updated = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);
    saveDriverToFirestore(updatedDriver);

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = updatedDriver;
      saveLocal(STORAGE_KEY_AUTH, updatedDriver);
    }
    notify();
  };

  // Admin Driver Actions
  const approveDriver = (driverId: string) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return;

    const updatedDriver: DriverProfile = {
      ...driver,
      status: 'AKTIF',
      rawStatus: 'approved',
      isOnline: true,
      rejectionReason: undefined,
    };
    const updated = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    // Update status langsung di Firebase Firestore via updateDoc(driverRef, { status: 'approved' })
    updateDriverStatusInFirestore(driverId, 'approved', {
      isOnline: true,
      rejectionReason: '',
    });

    // Kirim notifikasi WhatsApp Selamat Anda Diterima
    sendWhatsAppNotification(
      driver.phone,
      driver.name,
      'driver',
      'Selamat Anda Diterima!',
      `Selamat ${driver.name}, dokumen KTP & SIM A Anda telah DISETUJUI oleh Admin M3CAR. Sekarang Anda dapat langsung menerima order penumpang!`,
      'acc'
    );

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, status: 'AKTIF', rawStatus: 'approved', isOnline: true } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    playDriverAcceptedSound();
    notify();
  };

  const rejectDriver = (driverId: string, reason: string) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return;

    const updatedDriver: DriverProfile = {
      ...driver,
      status: 'DITOLAK',
      rawStatus: 'rejected',
      rejectionReason: reason,
      isOnline: false,
    };
    const updated = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    // Update status langsung di Firebase Firestore via updateDoc(driverRef, { status: 'rejected' })
    updateDriverStatusInFirestore(driverId, 'rejected', {
      isOnline: false,
      rejectionReason: reason,
    });

    // Kirim notifikasi WhatsApp Pendaftaran Ditolak
    sendWhatsAppNotification(
      driver.phone,
      driver.name,
      'driver',
      'Pendaftaran Ditolak',
      `Maaf ${driver.name}, verifikasi dokumen KTP/SIM A Driver M3CAR Anda DITOLAK. Alasan: ${reason}. Silakan unggah ulang foto KTP & SIM A yang jelas.`,
      'reject'
    );

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, status: 'DITOLAK', rawStatus: 'rejected', rejectionReason: reason, isOnline: false } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    notify();
  };

  const blockDriver = (driverId: string, reason: string) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return;

    const updatedDriver = { ...driver, status: 'DIBLOKIR' as const, rawStatus: 'blocked', blockReason: reason, isOnline: false };
    const updated = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    // Update status langsung ke Firebase Firestore
    updateDriverStatusInFirestore(driverId, 'blocked', {
      isOnline: false,
      blockReason: reason,
    });

    // Kirim notifikasi WhatsApp Akun Diblokir
    sendWhatsAppNotification(
      driver.phone,
      driver.name,
      'driver',
      'Akun Driver Diblokir',
      `Pemberitahuan: Akun Mitra Driver M3Car atas nama ${driver.name} telah DIBLOKIR oleh Admin Pusat karena: ${reason}. Anda tidak dapat menerima order perjalanan. Hubungi Admin di 085811594114 untuk klarifikasi.`,
      'block'
    );

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, status: 'DIBLOKIR', rawStatus: 'blocked', blockReason: reason, isOnline: false } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    notify();
  };

  const unblockDriver = (driverId: string) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return;

    const updatedDriver = { ...driver, status: 'AKTIF' as const, rawStatus: 'approved', blockReason: undefined, isOnline: true };
    const updated = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    // Update status langsung ke Firebase Firestore
    updateDriverStatusInFirestore(driverId, 'approved', {
      isOnline: true,
      blockReason: '',
    });

    // Kirim notifikasi WhatsApp Buka Blokir
    sendWhatsAppNotification(
      driver.phone,
      driver.name,
      'driver',
      'Blokir Akun Dibuka',
      `Halo ${driver.name}, blokir akun Driver M3Car Anda telah DIBUKA oleh Admin. Anda sekarang dapat kembali online dan menerima order penumpang. Selalu patuhi standar operasional M3Car.`,
      'unblock'
    );

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, status: 'AKTIF', rawStatus: 'approved', blockReason: undefined, isOnline: true } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    notify();
  };

  const syncDriverSnapshot = (driverId: string, partial: Partial<DriverProfile>) => {
    const existing = globalState.drivers.find((d) => d.id === driverId);
    const merged: DriverProfile = existing
      ? { ...existing, ...partial, id: driverId }
      : ({ id: driverId, role: 'driver', ...partial } as DriverProfile);

    const updated = existing
      ? globalState.drivers.map((d) => (d.id === driverId ? merged : d))
      : [merged, ...globalState.drivers];

    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = merged;
      saveLocal(STORAGE_KEY_AUTH, merged);
    }
    notify();
  };

  const setDriverOnlineStatus = (driverId: string, isOnline: boolean) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return;

    if (driver.status !== 'AKTIF' && isOnline) {
      return { success: false, message: 'Hanya driver berstatus AKTIF yang dapat ONLINE.' };
    }

    const updatedDriver = { ...driver, isOnline };
    const updated = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updated;
    saveLocal(STORAGE_KEY_DRIVERS, updated);

    // Sync to Firebase Firestore
    saveDriverToFirestore(updatedDriver);

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, isOnline } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    notify();
    return { success: true };
  };

  // Order Flow
  const createOrder = (orderData: {
    customerName: string;
    customerPhone: string;
    pickupLocation: string;
    destination: string;
    date: string;
    time: string;
    passengers: number;
    region?: RegionZone;
    pricePerPerson: number;
    totalPrice: number;
    route?: string;
    patokan?: string;
    pickupLat?: number;
    pickupLng?: number;
    mapsUrl?: string;
    dayName?: string;
    paymentMethod?: 'TUNAI' | 'TRANSFER_DRIVER' | 'QRIS_RTB' | 'M3CAR_PAY';
    isOutsideIndonesia?: boolean;
    country?: string;
    deviationKm?: number;
    deviationFee?: number;
    basePrice?: number;
  }) => {
    const isLongTrip = (orderData.region || 'jakarta') !== 'luar_jabodetabek';
    const rate = isLongTrip ? globalState.settings.commissionRates.longTrip : globalState.settings.commissionRates.shortTrip;
    const commissionAmount = Math.round(orderData.totalPrice * rate);
    const driverEarnings = orderData.totalPrice - commissionAmount;

    // Check Geofence & Deviation
    const geofence = checkIsOutsideIndonesia({
      address: orderData.pickupLocation,
      lat: orderData.pickupLat,
      lng: orderData.pickupLng,
      country: orderData.country,
    });
    const isOutsideIndonesia = orderData.isOutsideIndonesia ?? geofence.isOutsideIndonesia;
    const country = orderData.country || geofence.countryName;

    const dev = calculateCorridorDeviation({
      lat: orderData.pickupLat,
      lng: orderData.pickupLng,
      address: orderData.pickupLocation,
    });
    const deviationKm = orderData.deviationKm ?? dev.deviationKm;
    const deviationFee = orderData.deviationFee ?? dev.deviationFee;
    const basePrice = orderData.basePrice ?? orderData.passengers * (orderData.pricePerPerson || 270000);

    const derivedCustomerId =
      globalState.currentUser?.role === 'customer'
        ? globalState.currentUser.id
        : `cust-${orderData.customerPhone.replace(/\D/g, '')}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: `M3-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`,
      customerId: derivedCustomerId,
      customerName: orderData.customerName,
      customerPhone: orderData.customerPhone,
      pickupLocation: orderData.pickupLocation,
      dari: orderData.pickupLocation,
      pickupLat: orderData.pickupLat,
      pickupLng: orderData.pickupLng,
      destination: orderData.destination,
      ke: orderData.destination,
      route: orderData.route || `${orderData.pickupLocation} ➔ ${orderData.destination}`,
      patokan: orderData.patokan || '',
      mapsUrl: orderData.mapsUrl || (orderData.pickupLat && orderData.pickupLng ? `https://www.google.com/maps?q=${orderData.pickupLat},${orderData.pickupLng}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(orderData.pickupLocation)}`),
      dayName: orderData.dayName,
      date: orderData.date,
      time: orderData.time,
      passengers: orderData.passengers,
      region: orderData.region || 'jakarta',
      pricePerPerson: orderData.pricePerPerson,
      basePrice,
      deviationKm,
      deviationFee,
      totalPrice: orderData.totalPrice,
      harga: orderData.totalPrice,
      commissionRate: rate,
      commissionAmount,
      driverEarnings,
      tollRoute: 'Tol Jakarta-Merak + Tol Serang-Panimbang 83,6 km',
      eta: isOutsideIndonesia ? 'Di Luar Wilayah Layanan' : '6 jam 30 menit',
      status: 'MENCARI_DRIVER',
      isOutsideIndonesia,
      country,
      paymentMethod: orderData.paymentMethod || 'TUNAI',
      paymentStatus: 'BELUM_BAYAR',
      createdAt: new Date().toLocaleString('id-ID'),
      dispatchTimeRemaining: 60,
    };

    const updated = [newOrder, ...globalState.orders];
    globalState.orders = updated;
    saveLocal(STORAGE_KEY_ORDERS, updated);

    // Save customer to customers collection in Firestore
    saveCustomerToFirestore({
      id: derivedCustomerId,
      nama: orderData.customerName,
      no_hp: orderData.customerPhone,
      alamat: orderData.pickupLocation,
      tanggal_daftar: new Date().toLocaleString('id-ID'),
    });

    // Push real-time to Firebase Firestore orders collection
    saveOrderToFirestore(newOrder);

    // Play chime for incoming order notification
    playOrderAlertChime();

    // Trigger WhatsApp notification to Admin & Online Drivers
    sendWhatsAppNotification(
      globalState.settings.adminPhone,
      'Admin M3Car',
      'admin',
      'Pesanan Baru Masuk!',
      `Order baru ${newOrder.orderNumber}: ${orderData.customerName} (${orderData.passengers} org) rute ${orderData.pickupLocation} -> ${orderData.destination}. Total: Rp ${orderData.totalPrice.toLocaleString('id-ID')}`,
      'order'
    );

    notify();
    return newOrder;
  };

  const cancelOrderByCustomer = (orderId: string) => {
    const order = globalState.orders.find((o) => o.id === orderId);
    if (!order) return { success: false, message: 'Pesanan tidak ditemukan.' };

    if (order.status !== 'MENCARI_DRIVER') {
      return { success: false, message: 'Pesanan sudah diterima oleh Driver dan tidak dapat dibatalkan otomatis.' };
    }

    const updatedOrder = { ...order, status: 'DIBATALKAN' as const };
    const updated = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
    globalState.orders = updated;
    saveLocal(STORAGE_KEY_ORDERS, updated);

    // Sync to Firebase Firestore
    saveOrderToFirestore(updatedOrder);

    notify();
    return { success: true };
  };

  const cancelOrderByAdmin = (orderId: string, reason?: string) => {
    const order = globalState.orders.find((o) => o.id === orderId);
    if (!order) return { success: false, message: 'Pesanan tidak ditemukan.' };

    const cancelReason = reason || 'Ditolak / Dibatalkan oleh Admin Pusat M3Car';
    const updatedOrder: Order = {
      ...order,
      status: 'DIBATALKAN' as const,
    };
    const updated = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
    globalState.orders = updated;
    saveLocal(STORAGE_KEY_ORDERS, updated);

    // Sync to Firebase Firestore
    saveOrderToFirestore(updatedOrder);

    // Send WhatsApp notification
    sendWhatsAppNotification(
      order.customerPhone,
      order.customerName,
      'customer',
      'Pesanan Dibatalkan Admin',
      `Halo ${order.customerName}, pesanan ${order.orderNumber} telah DITOLAK / DIBATALKAN oleh Admin Pusat M3Car. Alasan: ${cancelReason}.`,
      'system'
    );

    notify();
    return { success: true };
  };

  const acceptOrderByDriver = (driverId: string, orderId: string) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    const order = globalState.orders.find((o) => o.id === orderId);

    if (!driver || !order) return { success: false, message: 'Data tidak ditemukan.' };
    if (order.status !== 'MENCARI_DRIVER') {
      return { success: false, message: 'Order ini sudah diambil driver lain atau telah dibatalkan.' };
    }

    // CHECK LOKASI LUAR INDONESIA (Rule 1: Tolak Otomatis)
    const geofence = checkIsOutsideIndonesia({
      address: order.pickupLocation,
      lat: order.pickupLat,
      lng: order.pickupLng,
      country: order.country,
    });
    if (order.isOutsideIndonesia || geofence.isOutsideIndonesia) {
      return {
        success: false,
        message: 'LOKASI DI LUAR JANGKAUAN! Order ini berada di luar wilayah Indonesia dan ditolak otomatis.',
      };
    }

    const currentBal = driver.saldo ?? driver.balance ?? 0;
    // CHECK SALDO DRIVER
    if (currentBal < order.commissionAmount) {
      return {
        success: false,
        isInsufficientBalance: true,
        required: order.commissionAmount,
        currentBalance: currentBal,
        message: `Saldo Kurang! Saldo Anda Rp ${currentBal.toLocaleString('id-ID')}, komisi yang dibutuhkan Rp ${order.commissionAmount.toLocaleString('id-ID')}. Silakan isi saldo M3Car Pay terlebih dahulu.`,
      };
    }

    // Deduct driver balance
    const newBalance = currentBal - order.commissionAmount;
    const updatedDriver = {
      ...driver,
      balance: newBalance,
      saldo: newBalance,
      totalTrips: driver.totalTrips + 1,
    };
    const updatedDrivers = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updatedDrivers;
    saveLocal(STORAGE_KEY_DRIVERS, updatedDrivers);

    // Push Driver Balance to Firebase Firestore
    saveDriverToFirestore(updatedDriver);

    // Record commission deduction transaction
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      driverId: driver.id,
      date: new Date().toLocaleString('id-ID'),
      type: 'POTONGAN_KOMISI',
      amount: -order.commissionAmount,
      balanceAfter: newBalance,
      description: `Potongan Komisi ${(order.commissionRate * 100).toFixed(0)}% Order ${order.orderNumber} (${order.pickupLocation} -> ${order.destination})`,
      orderId: order.id,
      paymentMethod: 'SYSTEM_COMMISSION',
      status: 'BERHASIL',
    };
    const updatedTx = [newTx, ...globalState.transactions];
    globalState.transactions = updatedTx;
    saveLocal(STORAGE_KEY_TRANSACTIONS, updatedTx);

    // Push Transaction to Firebase Firestore
    saveTransactionToFirestore(newTx, driver.phone);

    // Update order status to DRIVER_DITEMUKAN / DRIVER_OTW
    const updatedOrder: Order = {
      ...order,
      status: 'DRIVER_OTW' as const,
      driverId: driver.id,
      driverName: driver.name,
      driverPhone: driver.phone,
      driverPlate: driver.plateNumber,
      driverCar: driver.carModel,
      driverLocationProgress: 15,
      acceptedAt: new Date().toLocaleString('id-ID'),
    };
    const updatedOrders = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
    globalState.orders = updatedOrders;
    saveLocal(STORAGE_KEY_ORDERS, updatedOrders);

    // Push Order to Firebase Firestore
    saveOrderToFirestore(updatedOrder);

    // If current session is this driver, update
    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, balance: newBalance } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    // Send WhatsApp to Customer & Driver
    sendWhatsAppNotification(
      order.customerPhone,
      order.customerName,
      'customer',
      'Driver M3Car Ditemukan & Menuju Anda!',
      `Halo ${order.customerName}, pesanan ${order.orderNumber} telah DITERIMA oleh Driver ${driver.name} (Mobil ${driver.carModel}, Plat ${driver.plateNumber}). Driver sedang OTW menuju titik jemput Anda. Hubungi driver di ${driver.phone}.`,
      'order'
    );

    playSuccessChime();
    notify();
    return { success: true };
  };

  const rejectOrderByDriver = (driverId: string, orderId: string) => {
    const onlineDrivers = globalState.drivers.filter((d) => d.status === 'AKTIF' && d.isOnline && d.id !== driverId);
    const order = globalState.orders.find((o) => o.id === orderId);
    if (!order || order.status !== 'MENCARI_DRIVER') return;

    if (onlineDrivers.length > 0) {
      const nextDriver = onlineDrivers[0];
      sendWhatsAppNotification(
        nextDriver.phone,
        nextDriver.name,
        'driver',
        'Pesanan Diteruskan ke Anda!',
        `Order ${order.orderNumber} dialihkan ke Anda. Segera buka aplikasi M3Car untuk menerima order!`,
        'order'
      );
      playOrderAlertChime();
    }

    notify();
  };

  // Driver hanya bisa ganti foto profil saja (Nama, No WA, Plat dikunci total untuk driver)
  const updateDriverProfile = (
    driverId: string,
    data: { avatarUrl?: string }
  ) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return { success: false, message: 'Driver tidak ditemukan' };

    const updatedDriver: DriverProfile = {
      ...driver,
      avatarUrl: data.avatarUrl !== undefined ? data.avatarUrl : driver.avatarUrl,
    };

    const updatedDrivers = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updatedDrivers;
    saveLocal(STORAGE_KEY_DRIVERS, updatedDrivers);
    saveDriverToFirestore(updatedDriver);

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = updatedDriver;
      saveLocal(STORAGE_KEY_AUTH, updatedDriver);
    }

    notify();
    return { success: true, driver: updatedDriver };
  };

  // Hanya Admin yang bisa mengubah No HP dan Plat Nomor Driver
  const adminUpdateDriver = (
    driverId: string,
    data: { name?: string; phone?: string; plateNumber?: string; carModel?: string }
  ) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return { success: false, message: 'Driver tidak ditemukan' };

    const updatedDriver: DriverProfile = {
      ...driver,
      name: data.name !== undefined ? data.name.trim() : driver.name,
      phone: data.phone !== undefined ? data.phone.trim() : driver.phone,
      plateNumber: data.plateNumber !== undefined ? data.plateNumber.trim().toUpperCase() : driver.plateNumber,
      carModel: data.carModel !== undefined ? data.carModel.trim() : driver.carModel,
    };

    const updatedDrivers = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updatedDrivers;
    saveLocal(STORAGE_KEY_DRIVERS, updatedDrivers);
    saveDriverToFirestore(updatedDriver);

    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = updatedDriver;
      saveLocal(STORAGE_KEY_AUTH, updatedDriver);
    }

    notify();
    return { success: true, driver: updatedDriver };
  };

  const updateCustomerProfile = (
    customerId: string,
    data: { name: string; phone: string; avatarUrl?: string }
  ) => {
    const cleanName = data.name.trim() || 'Penumpang M3Car';
    const cleanPhone = data.phone.trim();

    const updatedCustDoc: CustomerData = {
      id: customerId,
      nama: cleanName,
      no_hp: cleanPhone,
      name: cleanName,
      phone: cleanPhone,
      avatarUrl: data.avatarUrl,
      foto_profil: data.avatarUrl,
      tanggal_daftar: new Date().toLocaleString('id-ID'),
      role: 'customer',
    };

    saveCustomerToFirestore(updatedCustDoc);

    const updatedCustomers = globalState.customers.map((c) =>
      c.id === customerId ? { ...c, ...updatedCustDoc } : c
    );
    if (!updatedCustomers.some((c) => c.id === customerId)) {
      updatedCustomers.unshift(updatedCustDoc);
    }
    globalState.customers = updatedCustomers;
    saveLocal(STORAGE_KEY_CUSTOMERS, updatedCustomers);

    const custUser: User = {
      id: customerId,
      name: cleanName,
      phone: cleanPhone,
      role: 'customer',
      avatarUrl: data.avatarUrl,
    };
    globalState.currentUser = custUser;
    saveLocal(STORAGE_KEY_AUTH, custUser);

    try {
      localStorage.setItem('m3car_penumpang_profile', JSON.stringify({
        name: cleanName,
        phone: cleanPhone,
        avatarUrl: data.avatarUrl,
      }));
    } catch {}

    notify();
    return { success: true, user: custUser };
  };

  const advanceOrderStatus = (orderId: string, nextStatus: OrderStatus) => {
    const target = globalState.orders.find((o) => o.id === orderId);
    if (!target) return;

    if (nextStatus === 'SUDAH_JEMPUT') {
      const updatedOrder: Order = {
        ...target,
        status: 'SUDAH_JEMPUT',
        driverLocationProgress: 50,
      };
      const updated = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
      globalState.orders = updated;
      saveLocal(STORAGE_KEY_ORDERS, updated);
      saveOrderToFirestore(updatedOrder);

      // Kirim Notifikasi + Bunyi ke Customer
      sendWhatsAppNotification(
        target.customerPhone,
        target.customerName,
        'customer',
        'Driver Sudah Jemput!',
        `Halo ${target.customerName}, Driver ${target.driverName || 'Mitra M3Car'} (${target.driverPlate || ''}) sudah menjemput Anda. Perjalanan ke tujuan telah dimulai. Selamat menikmati perjalanan!`,
        'order'
      );
      playPassengerNotificationChime();
      notify();
      return;
    }

    if (nextStatus === 'SUDAH_SAMPAI') {
      const updatedOrder: Order = {
        ...target,
        status: 'SUDAH_SAMPAI',
        driverLocationProgress: 95,
      };
      const updated = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
      globalState.orders = updated;
      saveLocal(STORAGE_KEY_ORDERS, updated);
      saveOrderToFirestore(updatedOrder);

      // Kirim Notifikasi + Bunyi ke Customer
      sendWhatsAppNotification(
        target.customerPhone,
        target.customerName,
        'customer',
        'Sudah Sampai di Tujuan!',
        `Halo ${target.customerName}, Anda telah sampai di tujuan: ${target.destination}. Pastikan tidak ada barang bawaan Anda yang tertinggal.`,
        'order'
      );
      playPassengerNotificationChime();
      notify();
      return;
    }

    if (nextStatus === 'SELESAI') {
      // Driver update total trips & balance
      if (target.driverId) {
        const driver = globalState.drivers.find((d) => d.id === target.driverId);
        if (driver) {
          const bonusEarnings = target.paymentMethod === 'QRIS_RTB' || target.paymentMethod === 'M3CAR_PAY' ? target.driverEarnings : 0;
          const updatedBalance = driver.balance + bonusEarnings;
          const updatedDriver: DriverProfile = {
            ...driver,
            balance: updatedBalance,
            totalTrips: driver.totalTrips + 1,
          };
          const updatedDrivers = globalState.drivers.map((d) => (d.id === driver.id ? updatedDriver : d));
          globalState.drivers = updatedDrivers;
          saveLocal(STORAGE_KEY_DRIVERS, updatedDrivers);
          saveDriverToFirestore(updatedDriver);

          if (bonusEarnings > 0) {
            const compTx: WalletTransaction = {
              id: `tx-earn-${Date.now()}`,
              driverId: driver.id,
              date: new Date().toLocaleString('id-ID'),
              type: 'ISI_SALDO',
              amount: bonusEarnings,
              balanceAfter: updatedBalance,
              description: `Pendapatan Bersih Order Selesai ${target.orderNumber}`,
              orderId: target.id,
              paymentMethod: 'SYSTEM_COMMISSION',
              status: 'BERHASIL',
            };
            const newTxList = [compTx, ...globalState.transactions];
            globalState.transactions = newTxList;
            saveLocal(STORAGE_KEY_TRANSACTIONS, newTxList);
            saveTransactionToFirestore(compTx, driver.phone);
          }
        }
      }

      // Catat Keuangan Admin
      const now = new Date().toLocaleString('id-ID');
      const omsetItem: KeuanganAdminItem = {
        id: `tx-omset-${target.id}`,
        id_transaksi: `TX-OMSET-${target.orderNumber}`,
        tanggal: now,
        jenis: 'masuk',
        keterangan: `Omset Order Selesai ${target.orderNumber} (${target.pickupLocation} ➔ ${target.destination})`,
        jumlah_rp: target.totalPrice,
        id_order: target.id,
        nama_driver: target.driverName,
        nama_customer: target.customerName,
        createdAt: new Date().toISOString(),
      };

      const komisiItem: KeuanganAdminItem = {
        id: `tx-komisi-${target.id}`,
        id_transaksi: `TX-KOMISI-${target.orderNumber}`,
        tanggal: now,
        jenis: 'masuk',
        keterangan: `Komisi Admin ${Math.round((target.commissionRate || 0.12) * 100)}% Order ${target.orderNumber}`,
        jumlah_rp: target.commissionAmount,
        id_order: target.id,
        nama_driver: target.driverName,
        nama_customer: target.customerName,
        createdAt: new Date().toISOString(),
      };

      const updatedFin = [komisiItem, omsetItem, ...globalState.keuanganAdmin];
      globalState.keuanganAdmin = updatedFin;
      saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, updatedFin);
      saveKeuanganAdminToFirestore(omsetItem);
      saveKeuanganAdminToFirestore(komisiItem);

      // Notifikasi WA Selesai
      sendWhatsAppNotification(
        target.customerPhone,
        target.customerName,
        'customer',
        'Perjalanan Selesai!',
        `Halo ${target.customerName}, perjalanan Anda (${target.orderNumber}) telah SELESAI. Terima kasih telah menggunakan layanan M3CAR!`,
        'order'
      );

      // 4. RIWAYAT HILANG SEMUA DENGAN NOTIFIKASI REALTIME:
      // Status SELESAI disiarkan terlebih dahulu ke Firestore agar Customer seketika menerima notifikasi + chime
      const finishedOrder: Order = {
        ...target,
        status: 'SELESAI',
        completedAt: new Date().toISOString(),
      };

      try {
        localStorage.setItem(
          'm3car_last_completed_order',
          JSON.stringify({
            orderId: target.id,
            orderNumber: target.orderNumber,
            customerPhone: target.customerPhone,
            customerName: target.customerName,
            driverName: target.driverName,
            destination: target.destination,
            timestamp: Date.now(),
          })
        );
      } catch {}

      saveOrderToFirestore(finishedOrder);

      playSuccessChime();
      playPassengerNotificationChime();
      notify();

      // Simpan status SELESAI di state dan database Firestore agar Admin dapat memantau riwayat order
      const updatedList = globalState.orders.map((o) => (o.id === orderId ? finishedOrder : o));
      globalState.orders = updatedList;
      saveLocal(STORAGE_KEY_ORDERS, updatedList);
      saveOrderToFirestore(finishedOrder);
      return;
    }

    const updatedOrder: Order = {
      ...target,
      status: nextStatus,
      completedAt: target.completedAt,
      driverLocationProgress: Math.min(90, (target.driverLocationProgress || 20) + 30),
    };
    const updated = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
    globalState.orders = updated;
    saveLocal(STORAGE_KEY_ORDERS, updated);
    saveOrderToFirestore(updatedOrder);
    notify();
  };

  // Konfirmasi Pembayaran Order (Tunai ke Driver, Transfer Driver, QRIS RTB Group, atau M3Car Pay)
  const confirmOrderPayment = (orderId: string, paymentMethod?: 'TUNAI' | 'TRANSFER_DRIVER' | 'QRIS_RTB' | 'M3CAR_PAY') => {
    const order = globalState.orders.find((o) => o.id === orderId);
    if (!order) return;

    const updatedOrder: Order = {
      ...order,
      paymentMethod: paymentMethod || order.paymentMethod || 'TUNAI',
      paymentStatus: 'LUNAS',
      paidAt: new Date().toLocaleString('id-ID'),
    };

    const updated = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
    globalState.orders = updated;
    saveLocal(STORAGE_KEY_ORDERS, updated);
    saveOrderToFirestore(updatedOrder);

    playSuccessChime();
    notify();
  };

  // M3CAR PAY - TOP UP SALDO DRIVER
  const topUpDriverSaldo = (driverId: string, nominal: number, paymentMethod: 'WA_TRANSFER' | 'QRIS' = 'WA_TRANSFER') => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    if (!driver) return { success: false, message: 'Driver tidak ditemukan.' };

    const newBalance = (driver.saldo ?? driver.balance ?? 0) + nominal;
    const updatedDriver = { ...driver, balance: newBalance, saldo: newBalance };
    const updatedDrivers = globalState.drivers.map((d) => (d.id === driverId ? updatedDriver : d));
    globalState.drivers = updatedDrivers;
    saveLocal(STORAGE_KEY_DRIVERS, updatedDrivers);

    // Push to Firebase Firestore
    saveDriverToFirestore(updatedDriver);

    // Record wallet transaction
    const newTx: WalletTransaction = {
      id: `tx-${Date.now()}`,
      driverId: driver.id,
      date: new Date().toLocaleString('id-ID'),
      type: 'ISI_SALDO',
      amount: nominal,
      balanceAfter: newBalance,
      description: `Top Up Saldo M3Car Pay Rp ${nominal.toLocaleString('id-ID')}`,
      paymentMethod,
      status: 'BERHASIL',
    };
    const updatedTx = [newTx, ...globalState.transactions];
    globalState.transactions = updatedTx;
    saveLocal(STORAGE_KEY_TRANSACTIONS, updatedTx);

    // Push to Firebase Firestore
    saveTransactionToFirestore(newTx, driver.phone);

    // Update current session if matching
    if (globalState.currentUser?.id === driverId) {
      globalState.currentUser = { ...globalState.currentUser, balance: newBalance } as DriverProfile;
      saveLocal(STORAGE_KEY_AUTH, globalState.currentUser);
    }

    sendWhatsAppNotification(
      driver.phone,
      driver.name,
      'driver',
      'Top Up Saldo M3Car Pay Berhasil',
      `Top Up Saldo BERHASIL! Saldo masuk Rp ${nominal.toLocaleString('id-ID')}. Total saldo Anda sekarang Rp ${newBalance.toLocaleString('id-ID')}. Terima kasih.`,
      'system'
    );

    playSuccessChime();
    notify();
    return { success: true, newBalance };
  };

  // 1. Create Top Up Request by Driver (DENGAN PENGECEKAN WAKTU RESIT & NOMINAL)
  const createTopUpRequest = (
    driverId: string,
    amount: number,
    receiptPhotoUrl?: string,
    receiptAmount?: number,
    receiptTime?: string,
    receiptTimestamp?: number,
    timeDiffMinutes?: number,
    receiptStatus?: 'RESIT_BARU' | 'RESIT_LAMA'
  ) => {
    const driver = globalState.drivers.find((d) => d.id === driverId);
    const bank = globalState.settings.companyBank || {
      bankName: 'SeaBank',
      accountNumber: '901102051050',
      accountHolder: 'Ali Husen - CV. ROYAL TRANS BERKAH GROUP',
    };

    const now = new Date().toLocaleString('id-ID');
    const newReq: DriverTopUpRequest = {
      id: `topup-${Date.now()}`,
      driverId,
      driverName: driver?.name || 'Driver',
      driverPhone: driver?.phone || '',
      driverPlate: driver?.plateNumber || '',
      amount,
      receiptPhotoUrl,
      receiptAmount: receiptAmount ?? amount,
      receiptTime: receiptTime || now.split(' ')[1] || 'Baru Saja',
      receiptTimestamp: receiptTimestamp || Date.now(),
      submitTime: now,
      timeDiffMinutes: timeDiffMinutes ?? 0,
      receiptStatus: receiptStatus || 'RESIT_BARU',
      bankName: bank.bankName,
      accountNumber: bank.accountNumber,
      accountHolder: bank.accountHolder,
      createdAt: now,
      status: 'MENUNGGU',
    };

    const updated = [newReq, ...globalState.topUpRequests];
    globalState.topUpRequests = updated;
    saveLocal(STORAGE_KEY_TOPUP_REQUESTS, updated);

    // Save to Firestore
    saveTopUpRequestToFirestore(newReq);

    notify();
    return newReq;
  };

  // 2. Approve Top Up Request by Admin (ADMIN TINGGAL KLIK OK SAJA, TANPA KETIK MANUAL)
  const approveTopUpRequest = (requestId: string) => {
    const req = globalState.topUpRequests.find((r) => r.id === requestId);
    if (!req) return { success: false, message: 'Permintaan tidak ditemukan.' };
    if (req.status !== 'MENUNGGU') return { success: false, message: 'Permintaan sudah diproses.' };

    const confirmedAt = new Date().toLocaleString('id-ID');
    const updatedReq: DriverTopUpRequest = {
      ...req,
      status: 'BERHASIL',
      confirmedAt,
    };

    const updatedRequests = globalState.topUpRequests.map((r) =>
      r.id === requestId ? updatedReq : r
    );
    globalState.topUpRequests = updatedRequests;
    saveLocal(STORAGE_KEY_TOPUP_REQUESTS, updatedRequests);
    saveTopUpRequestToFirestore(updatedReq);

    // Credit driver balance automatically with exact amount from database
    topUpDriverSaldo(req.driverId, req.amount, 'WA_TRANSFER');

    // Catat ke keuangan_admin sebagai Setoran Driver
    const finTopUp: KeuanganAdminItem = {
      id: `tx-topup-${req.id}`,
      id_transaksi: `TX-TOPUP-${req.id.slice(-6)}`,
      tanggal: confirmedAt,
      jenis: 'masuk',
      keterangan: `Setoran Top Up Saldo Driver ${req.driverName} (${req.driverPlate})`,
      jumlah_rp: req.amount,
      nama_driver: req.driverName,
      createdAt: new Date().toISOString(),
    };
    const updatedFin = [finTopUp, ...globalState.keuanganAdmin];
    globalState.keuanganAdmin = updatedFin;
    saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, updatedFin);
    saveKeuanganAdminToFirestore(finTopUp);

    playSuccessChime();
    notify();
    return { success: true };
  };

  // 3. Reject Top Up Request by Admin
  const rejectTopUpRequest = (requestId: string, reason?: string) => {
    const req = globalState.topUpRequests.find((r) => r.id === requestId);
    if (!req) return { success: false, message: 'Permintaan tidak ditemukan.' };

    const updatedReq: DriverTopUpRequest = {
      ...req,
      status: 'DITOLAK',
      confirmedAt: new Date().toLocaleString('id-ID'),
    };

    const updatedRequests = globalState.topUpRequests.map((r) =>
      r.id === requestId ? updatedReq : r
    );
    globalState.topUpRequests = updatedRequests;
    saveLocal(STORAGE_KEY_TOPUP_REQUESTS, updatedRequests);
    saveTopUpRequestToFirestore(updatedReq);

    sendWhatsAppNotification(
      req.driverPhone,
      req.driverName,
      'driver',
      'Top Up Ditolak',
      `Mohon maaf, permohonan top up Rp ${req.amount.toLocaleString('id-ID')} Anda belum dapat dikonfirmasi. ${reason || 'Silakan cek bukti transfer Anda atau hubungi Direktur Ali Husen.'}`,
      'system'
    );

    notify();
    return { success: true };
  };

  // Top up via QRIS / Tripay
  const topUpDriverSaldoViaQrisTripay = (driverId: string, nominal: number) => {
    return topUpDriverSaldo(driverId, nominal, 'QRIS');
  };

  // Manual entry for Keuangan Admin
  const addKeuanganTransaction = (item: {
    jenis: 'masuk' | 'keluar';
    keterangan: string;
    jumlah_rp: number;
    nama_driver?: string;
    nama_customer?: string;
  }) => {
    const now = new Date().toLocaleString('id-ID');
    const newFin: KeuanganAdminItem = {
      id: `tx-manual-${Date.now()}`,
      id_transaksi: `TX-M-${Date.now().toString().slice(-6)}`,
      tanggal: now,
      jenis: item.jenis,
      keterangan: item.keterangan,
      jumlah_rp: item.jumlah_rp,
      nama_driver: item.nama_driver || '',
      nama_customer: item.nama_customer || '',
      createdAt: new Date().toISOString(),
    };
    const updated = [newFin, ...globalState.keuanganAdmin];
    globalState.keuanganAdmin = updated;
    saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, updated);
    saveKeuanganAdminToFirestore(newFin);
    notify();
    return newFin;
  };

  // 2. SISTEM KOTAK SAMPAH (TRASH) 2 TAHAP
  // Tahap 1: Pindahkan ke Kotak Sampah (soft delete)
  const moveToTrash = (category: 'order' | 'driver' | 'customer' | 'finance' | 'keuangan', id: string) => {
    const now = new Date().toLocaleString('id-ID');
    if (category === 'order') {
      const target = globalState.orders.find((o) => o.id === id);
      if (!target) return;
      const updatedOrder = { ...target, isDeleted: true, deletedAt: now };
      globalState.orders = globalState.orders.map((o) => (o.id === id ? updatedOrder : o));
      saveLocal(STORAGE_KEY_ORDERS, globalState.orders);
      saveOrderToFirestore(updatedOrder);
    } else if (category === 'driver') {
      const target = globalState.drivers.find((d) => d.id === id);
      if (!target) return;
      const updatedDriver = { ...target, isDeleted: true, deletedAt: now };
      globalState.drivers = globalState.drivers.map((d) => (d.id === id ? updatedDriver : d));
      saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
      saveDriverToFirestore(updatedDriver);
    } else if (category === 'customer') {
      const target = globalState.customers.find((c) => c.id === id || c.no_hp === id || c.phone === id);
      if (!target) return;
      const updatedCust = { ...target, isDeleted: true, deletedAt: now };
      globalState.customers = globalState.customers.map((c) => (c.id === target.id ? updatedCust : c));
      saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);
      saveCustomerToFirestore(updatedCust);
    } else if (category === 'finance' || category === 'keuangan') {
      const target = globalState.keuanganAdmin.find((k) => k.id === id);
      if (!target) return;
      const updatedItem = { ...target, isDeleted: true, deletedAt: now };
      globalState.keuanganAdmin = globalState.keuanganAdmin.map((k) => (k.id === id ? updatedItem : k));
      saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin);
      saveKeuanganAdminToFirestore(updatedItem);
    }
    notify();
  };

  // Tahap 2A: Kembalikan Data dari Kotak Sampah (Restore)
  const restoreFromTrash = (category: 'order' | 'driver' | 'customer' | 'finance' | 'keuangan', id: string) => {
    if (category === 'order') {
      const target = globalState.orders.find((o) => o.id === id);
      if (!target) return;
      const updatedOrder = { ...target, isDeleted: false, deletedAt: undefined };
      globalState.orders = globalState.orders.map((o) => (o.id === id ? updatedOrder : o));
      saveLocal(STORAGE_KEY_ORDERS, globalState.orders);
      saveOrderToFirestore(updatedOrder);
    } else if (category === 'driver') {
      const target = globalState.drivers.find((d) => d.id === id);
      if (!target) return;
      const updatedDriver = { ...target, isDeleted: false, deletedAt: undefined };
      globalState.drivers = globalState.drivers.map((d) => (d.id === id ? updatedDriver : d));
      saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
      saveDriverToFirestore(updatedDriver);
    } else if (category === 'customer') {
      const target = globalState.customers.find((c) => c.id === id || c.no_hp === id || c.phone === id);
      if (!target) return;
      const updatedCust = { ...target, isDeleted: false, deletedAt: undefined };
      globalState.customers = globalState.customers.map((c) => (c.id === target.id ? updatedCust : c));
      saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);
      saveCustomerToFirestore(updatedCust);
    } else if (category === 'finance' || category === 'keuangan') {
      const target = globalState.keuanganAdmin.find((k) => k.id === id);
      if (!target) return;
      const updatedItem = { ...target, isDeleted: false, deletedAt: undefined };
      globalState.keuanganAdmin = globalState.keuanganAdmin.map((k) => (k.id === id ? updatedItem : k));
      saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin);
      saveKeuanganAdminToFirestore(updatedItem);
    }
    notify();
  };

  // Tahap 2B: Hapus Permanen Selamanya (Delete Forever)
  const permanentDelete = (category: 'order' | 'driver' | 'customer' | 'finance' | 'keuangan', id: string) => {
    if (category === 'order') {
      globalState.orders = globalState.orders.filter((o) => o.id !== id);
      saveLocal(STORAGE_KEY_ORDERS, globalState.orders);
      deleteOrderFromFirestore(id);
    } else if (category === 'driver') {
      globalState.drivers = globalState.drivers.filter((d) => d.id !== id);
      saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
      deleteDriverFromFirestore(id);
    } else if (category === 'customer') {
      const target = globalState.customers.find((c) => c.id === id || c.no_hp === id || c.phone === id);
      const targetId = target ? target.id : id;
      globalState.customers = globalState.customers.filter((c) => c.id !== id && c.no_hp !== id && c.phone !== id);
      saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);
      deleteCustomerFromFirestore(targetId);
    } else if (category === 'finance' || category === 'keuangan') {
      globalState.keuanganAdmin = globalState.keuanganAdmin.filter((k) => k.id !== id);
      saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin);
      deleteKeuanganAdminFromFirestore(id);
    }
    notify();
  };

  // Kosongkan Seluruh Kotak Sampah Sekaligus
  const emptyTrash = () => {
    const trashedOrders = globalState.orders.filter((o) => o.isDeleted);
    const trashedDrivers = globalState.drivers.filter((d) => d.isDeleted);
    const trashedCust = globalState.customers.filter((c) => c.isDeleted);
    const trashedFin = globalState.keuanganAdmin.filter((f) => f.isDeleted);

    trashedOrders.forEach((o) => deleteOrderFromFirestore(o.id));
    trashedDrivers.forEach((d) => deleteDriverFromFirestore(d.id));
    trashedCust.forEach((c) => deleteCustomerFromFirestore(c.id));
    trashedFin.forEach((f) => deleteKeuanganAdminFromFirestore(f.id));

    globalState.orders = globalState.orders.filter((o) => !o.isDeleted);
    globalState.drivers = globalState.drivers.filter((d) => !d.isDeleted);
    globalState.customers = globalState.customers.filter((c) => !c.isDeleted);
    globalState.keuanganAdmin = globalState.keuanganAdmin.filter((f) => !f.isDeleted);

    saveLocal(STORAGE_KEY_ORDERS, globalState.orders);
    saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
    saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);
    saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin);
    notify();
  };

  // Update Admin Settings & sync to Firestore
  const updateSettings = (newSettings: Partial<AdminSettings>) => {
    const updated: AdminSettings = {
      ...globalState.settings,
      ...newSettings,
      pricePerPerson: newSettings.pricePerPerson !== undefined ? newSettings.pricePerPerson : globalState.settings.pricePerPerson,
      pricePerKm: newSettings.pricePerKm !== undefined ? newSettings.pricePerKm : globalState.settings.pricePerKm,
      receiptTimeLimitMinutes: newSettings.receiptTimeLimitMinutes || globalState.settings.receiptTimeLimitMinutes || 30,
      rates: {
        ...globalState.settings.rates,
        ...(newSettings.rates || {}),
      },
      commissionRates: {
        ...globalState.settings.commissionRates,
        ...(newSettings.commissionRates || {}),
      },
      siteContent: {
        ...globalState.settings.siteContent,
        ...(newSettings.siteContent || {}),
      },
      companyBank: newSettings.companyBank
        ? { ...globalState.settings.companyBank, ...newSettings.companyBank }
        : globalState.settings.companyBank,
    };
    globalState.settings = updated;
    saveLocal(STORAGE_KEY_SETTINGS, updated);
    saveAdminSettingsToFirestore(updated);
    notify();
  };

  // 4. Update Company Bank Account Info
  const updateCompanyBank = (bank: CompanyBankAccount) => {
    updateSettings({ companyBank: bank });
  };

  // Explicit Deletion Functions for Admin Panel
  const deleteOrder = (orderId: string) => {
    globalState.orders = globalState.orders.filter((o) => o.id !== orderId);
    saveLocal(STORAGE_KEY_ORDERS, globalState.orders);
    deleteOrderFromFirestore(orderId);
    notify();
  };

  const deleteDriver = (driverId: string) => {
    globalState.drivers = globalState.drivers.filter((d) => d.id !== driverId);
    saveLocal(STORAGE_KEY_DRIVERS, globalState.drivers);
    deleteDriverFromFirestore(driverId);
    notify();
  };

  const deleteCustomer = (customerId: string) => {
    const target = globalState.customers.find((c) => c.id === customerId || c.no_hp === customerId || c.phone === customerId);
    const targetId = target ? target.id : customerId;
    globalState.customers = globalState.customers.filter((c) => c.id !== customerId && c.no_hp !== customerId && c.phone !== customerId);
    saveLocal(STORAGE_KEY_CUSTOMERS, globalState.customers);
    deleteCustomerFromFirestore(targetId);
    notify();
  };

  const clearAllCustomers = () => {
    const ids = globalState.customers.map((c) => c.id);
    globalState.customers = [];
    saveLocal(STORAGE_KEY_CUSTOMERS, []);
    clearAllCustomersFromFirestore(ids);
    notify();
  };

  const deleteTransaction = (txId: string) => {
    globalState.transactions = globalState.transactions.filter((t) => t.id !== txId);
    saveLocal(STORAGE_KEY_TRANSACTIONS, globalState.transactions);
    deleteTransactionFromFirestore(txId);
    notify();
  };

  const clearAllTransactions = () => {
    const ids = globalState.transactions.map((t) => t.id);
    globalState.transactions = [];
    saveLocal(STORAGE_KEY_TRANSACTIONS, []);
    clearAllTransactionsFromFirestore(ids);
    notify();
  };

  const deleteTopUpRequest = (reqId: string) => {
    globalState.topUpRequests = globalState.topUpRequests.filter((r) => r.id !== reqId);
    saveLocal(STORAGE_KEY_TOPUP_REQUESTS, globalState.topUpRequests);
    deleteTopUpRequestFromFirestore(reqId);
    notify();
  };

  const clearAllTopUpRequests = () => {
    const ids = globalState.topUpRequests.map((r) => r.id);
    globalState.topUpRequests = [];
    saveLocal(STORAGE_KEY_TOPUP_REQUESTS, []);
    clearAllTopUpRequestsFromFirestore(ids);
    notify();
  };

  const deleteKeuanganItem = (id: string) => {
    globalState.keuanganAdmin = globalState.keuanganAdmin.filter((k) => k.id !== id);
    saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, globalState.keuanganAdmin);
    deleteKeuanganAdminFromFirestore(id);
    notify();
  };

  const clearAllKeuangan = () => {
    const ids = globalState.keuanganAdmin.map((k) => k.id);
    globalState.keuanganAdmin = [];
    saveLocal(STORAGE_KEY_KEUANGAN_ADMIN, []);
    ids.forEach((id) => deleteKeuanganAdminFromFirestore(id));
    notify();
  };

  // Route Management Actions (Stored in Firebase setting_admin/config)
  const addRoute = (input: Omit<TravelRoute, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newRoute: TravelRoute = {
      id: `route-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      kotaAsal: input.kotaAsal.trim(),
      provinsiAsal: input.provinsiAsal.trim(),
      kotaTujuan: input.kotaTujuan.trim(),
      provinsiTujuan: input.provinsiTujuan.trim(),
      status: input.status || 'AKTIF',
      createdAt: now,
      updatedAt: now,
    };
    const nextRoutes = [newRoute, ...(globalState.settings.routes || [])];
    updateSettings({ routes: nextRoutes });
    return newRoute;
  };

  const updateRoute = (routeId: string, patch: Partial<TravelRoute>) => {
    const nextRoutes = (globalState.settings.routes || []).map((r) =>
      r.id === routeId ? { ...r, ...patch, updatedAt: new Date().toISOString() } : r
    );
    updateSettings({ routes: nextRoutes });
  };

  const deleteRoute = (routeId: string) => {
    const nextRoutes = (globalState.settings.routes || []).filter((r) => r.id !== routeId);
    updateSettings({ routes: nextRoutes });
  };

  const toggleRouteStatus = (routeId: string) => {
    const nextRoutes = (globalState.settings.routes || []).map((r) =>
      r.id === routeId
        ? {
            ...r,
            status: (r.status === 'AKTIF' ? 'NONAKTIF' : 'AKTIF') as TravelRoute['status'],
            updatedAt: new Date().toISOString(),
          }
        : r
    );
    updateSettings({ routes: nextRoutes });
  };

  // Price Tariff Management Actions (Stored in Firebase setting_admin/config)
  const addTariff = (input: Omit<PriceTariff, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newTariff: PriceTariff = {
      id: `tariff-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      routeId: input.routeId,
      namaRute: input.namaRute.trim(),
      hargaPerOrang: Number(input.hargaPerOrang) || 0,
      hargaSekaliJalan: Number(input.hargaSekaliJalan) || 0,
      hargaPulangPergi: Number(input.hargaPulangPergi) || 0,
      aktif: Boolean(input.aktif),
      createdAt: now,
      updatedAt: now,
    };
    const nextTariffs = [newTariff, ...(globalState.settings.tariffs || [])];
    updateSettings({ tariffs: nextTariffs });
    return newTariff;
  };

  const updateTariff = (tariffId: string, patch: Partial<PriceTariff>) => {
    const nextTariffs = (globalState.settings.tariffs || []).map((t) =>
      t.id === tariffId ? { ...t, ...patch, updatedAt: new Date().toISOString() } : t
    );
    updateSettings({ tariffs: nextTariffs });
  };

  const deleteTariff = (tariffId: string) => {
    const nextTariffs = (globalState.settings.tariffs || []).filter((t) => t.id !== tariffId);
    updateSettings({ tariffs: nextTariffs });
  };

  const toggleTariffStatus = (tariffId: string) => {
    const nextTariffs = (globalState.settings.tariffs || []).map((t) =>
      t.id === tariffId ? { ...t, aktif: !t.aktif, updatedAt: new Date().toISOString() } : t
    );
    updateSettings({ tariffs: nextTariffs });
  };

  const updateOrderStatusAdmin = (orderId: string, nextStatus: OrderStatus, extra?: Partial<Order>) => {
    const target = globalState.orders.find((o) => o.id === orderId);
    if (!target) return;
    if (nextStatus === 'SELESAI' && target.status !== 'SELESAI') {
      advanceOrderStatus(orderId, 'SELESAI');
      return;
    }
    const updatedOrder: Order = {
      ...target,
      ...extra,
      status: nextStatus,
    };
    globalState.orders = globalState.orders.map((o) => (o.id === orderId ? updatedOrder : o));
    saveLocal(STORAGE_KEY_ORDERS, globalState.orders);
    saveOrderToFirestore(updatedOrder);
    notify();
  };

  return {
    currentUser: globalState.currentUser,
    isAdminAuthenticated: globalState.isAdminAuthenticated,
    isCheckingAdminSession: globalState.isCheckingAdminSession,
    customers: globalState.customers,
    drivers: globalState.drivers,
    orders: globalState.orders,
    transactions: globalState.transactions,
    topUpRequests: globalState.topUpRequests,
    keuanganAdmin: globalState.keuanganAdmin,
    settings: globalState.settings,
    notifications: globalState.notifications,
    isFirebaseConnected: globalState.isFirebaseConnected,
    verifyAdminSessionWithServer,
    loginAdminWithServer,
    logoutAdminWithServer,
    changeAdminCodeWithServer,
    login,
    logout,
    switchRole,
    registerCustomer,
    registerDriver,
    loginDriverWithPassword,
    setupFirstTimeDriverPassword,
    recoverDriverPassword,
    generateDriverRecoveryCode,
    resubmitDriverDocuments,
    approveDriver,
    rejectDriver,
    blockDriver,
    unblockDriver,
    syncDriverSnapshot,
    setDriverOnlineStatus,
    createOrder,
    cancelOrderByCustomer,
    cancelOrderByAdmin,
    acceptOrderByDriver,
    rejectOrderByDriver,
    advanceOrderStatus,
    updateOrderStatusAdmin,
    confirmOrderPayment,
    topUpDriverSaldo,
    topUpDriverSaldoViaQrisTripay,
    createTopUpRequest,
    approveTopUpRequest,
    rejectTopUpRequest,
    updateCompanyBank,
    updateSettings,
    addRoute,
    updateRoute,
    deleteRoute,
    toggleRouteStatus,
    addTariff,
    updateTariff,
    deleteTariff,
    toggleTariffStatus,
    addKeuanganTransaction,
    deleteOrder,
    deleteDriver,
    deleteCustomer,
    clearAllCustomers,
    deleteTransaction,
    clearAllTransactions,
    deleteTopUpRequest,
    clearAllTopUpRequests,
    deleteKeuanganItem,
    clearAllKeuangan,
    moveToTrash,
    restoreFromTrash,
    permanentDelete,
    emptyTrash,
    sendWhatsAppNotification,
    loginUnified,
    updateDriverProfile,
    adminUpdateDriver,
    updateCustomerProfile,
    fetchPaginatedOrders,
    fetchPaginatedCustomers,
    updateOrderInFirestore,
  };
}
